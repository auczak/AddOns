SolarianAlarm v1.6 WoW AddOn by Lenja of Frostmourne EU
-------------------------------------------------------

"Turns your whole screen deep blue when you get debuffed with Wrath of the Astromancer. It is IMPOSSIBLE to miss that!"

The text "SolarianAlarm loaded!" will appear in the chat window when you start the client and the addon is active. From then on, you will always be warned by turning the screen blue when you get Solarian's debuff. For testing purposes, use "/solarianalarm test on" and the screen will turn blue on ANY debuff and will remain so until the debuff is gone. You can easily test this by using a bandage on yourself. Turn test mode off again with "/solarianalarm test off" to go back to normal mode. You can also issue a version check with "/solarianalarm version check" to see what SA versions your raid members are using.
