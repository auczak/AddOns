--[[
--
--	QDKP2_Chron
--		Keeper of Time
--
--	By AnduinLothar, Alexander Brazie, and Thott 
--
--	QDKP2_Chron manages time. You can schedule a function to be called
--	in X seconds, with or without an id. You can request a timer, 
--	which tracks the elapsed duration since the timer was started. 
--
--  To use as an embeddable addon:
--	- Put the QDKP2_Chron folder inside your Interface/AddOns/<YourAddonName>/ folder.
--	- Add QDKP2_Chron\QDKP2_Chron_xml to your toc or load it in your xml before your localization files.
--	- Add QDKP2_Chron to the OptionalDeps in your toc
--	
--	To use as an addon library:
--	- Put the QDKP2_Chron folder inside your Interface/AddOns/ folder.
--	- Add QDKP2_Chron to the Dependencies in your toc
--
--	Please see below or see http://www.wowwiki.com/QDKP2_Chron for details.
--
--	$LastChangedBy: karlkfi $
--	$Date: 2006-10-13 16:45:09 -0500 (Fri, 13 Oct 2006) $
--	$Rev: 4161 $
--	
--]]

local QDKP2_Chron_REV = 2.11;

local isBetterInstanceLoaded = false

if (not isBetterInstanceLoaded) then
	
	if (not QDKP2_Chron) then
		QDKP2_Chron = {};
	end
	
	QDKP2_Chron_version = QDKP2_Chron_REV;
	
	------------------------------------------------------------------------------
	--[[ Variables ]]--
	------------------------------------------------------------------------------
	
	QDKP2_Chron_online = true;
	
	QDKP2_Chron_DEBUG = false;
	QDKP2_Chron_DEBUG_WARNINGS = false;

	-- QDKP2_Chron Data
	if (not QDKP2_ChronData) then
		QDKP2_ChronData = {};
	end
	
	-- QDKP2_Chron Recycled Tables Storage
	if (not QDKP2_Chron_tables) then
		QDKP2_Chron_tables = {};
	end
		
	-- Initialize the Timers
	if (not QDKP2_ChronData.timers) then
		QDKP2_ChronData.timers = {};
	end
	
	-- Initialize the perform-over-time task list
	if (not QDKP2_ChronData.tasks) then
		QDKP2_ChronData.tasks = {};
	end
		
	-- Maximum items per frame
	QDKP2_Chron_MAX_TASKS_PER_FRAME = 100;
		
	-- Maximum steps per task
	QDKP2_Chron_MAX_STEPS_PER_TASK = 300;
	
	-- Maximum time delay per frame
	QDKP2_Chron_MAX_TIME_PER_STEP = .3;
		
	QDKP2_Chron_emptyTable = {};
	
	------------------------------------------------------------------------------
	--[[ User Functions ]]--
	------------------------------------------------------------------------------
	
	--[[
	-- debug(boolean)
	-- 
	-- Toggles debug mode
	]]--
	function QDKP2_Chron_debug(enable)
		if (enable) then
			QDKP2_ChronFrame:SetScript("OnUpdate", QDKP2_Chron_OnUpdate_Debug);
			QDKP2_Chron_DEBUG = true;
			QDKP2_Chron_DEBUG_WARNINGS = true;
		else
			QDKP2_ChronFrame:SetScript("OnUpdate", QDKP2_Chron_OnUpdate_Quick);
			QDKP2_Chron_DEBUG = false;
			QDKP2_Chron_DEBUG_WARNINGS = false;
		end
	end
	
	--[[
	-- Scheduling functions
	-- Parts rewritten by AnduinLothar for efficiency
	-- Parts rewritten by Thott for speed
	-- Written by Alexander
	-- Original by Thott
	--
	-- Usage: QDKP2_Chron_schedule(when,handler,arg1,arg2,etc)
	--
	-- After <when> seconds pass (values less than one and fractional values are
	-- fine), handler is called with the specified arguments, i.e.:
	--	 handler(arg1,arg2,etc)
	--
	-- If you'd like to have something done every X seconds, reschedule
	-- it each time in the handler or preferably use scheduleRepeating.
	--
	-- Also, please note that there is a limit to the number of
	-- scheduled tasks that can be performed per xml object at the
	-- same time. 
	--]]
	function QDKP2_Chron_schedule(when, handler, ...)
		if ( not QDKP2_Chron_online ) then 
			return;
		end
		if ( not handler) then
			QDKP2_Chron_printError("ERROR: nil handler passed to QDKP2_Chron_schedule()");
			return;
		end
				
		--local memstart = collectgarbage("count");
		-- -- Assign an id
		-- local id = "";
		-- if ( not this ) then 
		-- 	id = "Keybinding";
		-- else
		-- 	id = this:GetName();
		-- end
		-- if ( not id ) then 
		-- 	id = "_DEFAULT";
		-- end
		-- if ( not when ) then 
		-- 	QDKP2_Chron_printDebugError("QDKP2_Chron_DEBUG_WARNINGS", "QDKP2_Chron Error Detection: ", id , " has sent no interval for this function. ", when );
		-- 	return;
		-- end

		-- -- Ensure we're not looping QDKP2_ChronFrame
		-- if ( id == "QDKP2_ChronFrame" and QDKP2_ChronData.lastID ) then 
		-- 	id = QDKP2_ChronData.lastID;
		-- end

		-- use recycled tables to avoid excessive garbage collection -AnduinLothar
		--tinsert(QDKP2_ChronData.sched, QDKP2_Chron_getTable())
		--local i = #QDKP2_ChronData.sched
		local recTable = QDKP2_Chron_getTable()
		-- QDKP2_ChronData.sched[i].id = id;
		recTable.time = when + GetTime();
		recTable.handler = handler;
		recTable.args = QDKP2_Chron_getArgTable(...);

		-- task list is a heap, add new
		local i = #QDKP2_ChronData.sched+1
		while(i > 1) do
			if(recTable.time < QDKP2_ChronData.sched[i-1].time) then
				i = i - 1;
			else
				break
			end
		end
		tinsert(QDKP2_ChronData.sched, i, recTable)
		
		-- Debug print
		--QDKP2_Chron_printDebugError("QDKP2_Chron_DEBUG", "Scheduled "..handler.." in "..when.." seconds from "..id );
		--QDKP2_Chron_printError("Memory change in schedule: "..memstart.."->"..memend.." = "..memend-memstart);
	end
	

	--[[
	--	QDKP2_Chron_scheduleByName(name, delay, function, arg1, ... );
	--
	-- Same as QDKP2_Chron_schedule, except it takes a schedule name argument.
	-- Only one event can be scheduled with a given name at any one time.
	-- Thus if one exists, and another one is scheduled, the first one
	-- is deleted, then the second one added.
	--
	--]]
	function QDKP2_Chron_scheduleByName(name, when, handler, ...)
		if ( not name ) then 
			QDKP2_Chron_printDebugError("QDKP2_Chron_DEBUG_WARNINGS","QDKP2_Chron Error Detection: No name specified to QDKP2_Chron_scheduleByName");
			return;
		end
		local namedSchedule = QDKP2_ChronData.byName[name];
		if(namedSchedule and handler) then
			QDKP2_Chron_printDebugError("QDKP2_Chron_DEBUG_WARNINGS","QDKP2_Chron Error Detection: scheduleByName is reasigning \"".. name.."\".");
			QDKP2_Chron_releaseTable(QDKP2_ChronData.byName[name]);
		else
			if ( not handler ) then
				if ( not namedSchedule ) then
					QDKP2_Chron_printDebugError("QDKP2_Chron_DEBUG_WARNINGS","QDKP2_Chron Error Detection: No handler specified to QDKP2_Chron_scheduleByName, no previous entry found for scheduled entry \"".. name.."\".");
					return;
				end
				if ( not namedSchedule.handler ) then
					QDKP2_Chron_printDebugError("QDKP2_Chron_DEBUG_WARNINGS","QDKP2_Chron Error Detection: No handler specified to QDKP2_Chron_scheduleByName, no handler could be found in previous entry of \"".. name.."\" either.");
					return;
				end
				handler = namedSchedule.handler;
				QDKP2_Chron_printDebugError("QDKP2_Chron_DEBUG_WARNINGS","QDKP2_Chron: scheduleByName is updating \"".. name.."\" to time: ".. when);
			else
				QDKP2_Chron_printDebugError("QDKP2_Chron_DEBUG_WARNINGS","QDKP2_Chron: scheduleByName is asigning \"".. name.."\".");
			end
		end
		QDKP2_ChronData.byName[name] = QDKP2_Chron_getTable();
		namedSchedule = QDKP2_ChronData.byName[name];
		namedSchedule.time = when+GetTime()
		namedSchedule.handler = handler;
		namedSchedule.args = QDKP2_Chron_getArgTable(...);
	end

	--[[
	--	unscheduleByName(name);
	--
	--		Removes an entry that was created with scheduleByName()
	--
	--	Args:
	--		name - the name used
	--
	--]]
	function QDKP2_Chron_unscheduleByName(name)
		if ( not QDKP2_Chron_online ) then 
			return;
		end
		if ( not name ) then 
			QDKP2_Chron_printError("No name specified to QDKP2_Chron_unscheduleByName");
			return;
		end
		if(QDKP2_ChronData.byName[name]) then
			QDKP2_Chron_releaseTable(QDKP2_ChronData.byName[name]);
			QDKP2_ChronData.byName[name] = nil;
		end
		
		-- Debug print
		--QDKP2_Chron_printDebugError("QDKP2_Chron_DEBUG", "Cancelled scheduled timer of name ",name);
	end
	
	--[[
	--	unscheduleRepeating(name);
	--		Mirrors unscheduleByName for backwards compatibility
	--]]
	QDKP2_Chron_unscheduleRepeating = QDKP2_Chron_unscheduleByName;

	--[[
	--	isScheduledByName(name)
	--		Returns the amount of time left if it is indeed scheduled by name!
	--
	--	returns:
	--		number - time remaining
	--		nil - not scheduled
	--
	--]]
	function QDKP2_Chron_isScheduledByName(name)
		if ( not QDKP2_Chron_online ) then 
			return;
		end
		if ( not name ) then 
			QDKP2_Chron_printError("No name specified to QDKP2_Chron_isScheduledByName "..(this:GetName() or "unknown"));
			return;
		end
		local namedSchedule = QDKP2_ChronData.byName[name];
		if(namedSchedule) then
			return namedSchedule.time - GetTime();
		end
		
		-- Debug print
		--QDKP2_Chron_printDebugError("QDKP2_Chron_DEBUG", "Did not find timer of name ",name);
		return nil;
	end
	
	--[[
	--	isScheduledRepeating(name)	
	--		Mirrors isScheduledByName for backwards compatibility
	--]]
	QDKP2_Chron_isScheduledRepeating = QDKP2_Chron_isScheduledByName;
	
	--[[
	--	QDKP2_Chron_scheduleRepeating(name, delay, function);
	--
	-- Same as QDKP2_Chron_scheduleByName, except it repeats without recalling and takes no arguments.
	--
	--]]
	function QDKP2_Chron_scheduleRepeating(name, when, handler)
		if ( not name ) then 
			QDKP2_Chron_printDebugError("QDKP2_Chron_DEBUG_WARNINGS","QDKP2_Chron Error Detection: No name specified to QDKP2_Chron_scheduleRepeating");
			return;
		end
		local namedSchedule = QDKP2_ChronData.byName[name];
		if(namedSchedule and handler) then
			QDKP2_Chron_printDebugError("QDKP2_Chron_DEBUG_WARNINGS","QDKP2_Chron Error Detection: scheduleRepeating is reasigning ".. name);
			QDKP2_Chron_releaseTable(QDKP2_ChronData.byName[name]);
		else
			if ( not handler ) then
				if ( not namedSchedule ) then
					QDKP2_Chron_printDebugError("QDKP2_Chron_DEBUG_WARNINGS","QDKP2_Chron Error Detection: No handler specified to QDKP2_Chron_scheduleRepeating, no previous entry found for scheduled entry '".. name.."'.");
					return;
				end
				if ( not namedSchedule.handler ) then
					QDKP2_Chron_printDebugError("QDKP2_Chron_DEBUG_WARNINGS","QDKP2_Chron Error Detection: No handler specified to QDKP2_Chron_scheduleRepeating, no handler could be found in previous entry '".. name.."' either.");
					return;
				end
				handler = namedSchedule.handler;
				QDKP2_Chron_printDebugError("QDKP2_Chron_DEBUG_WARNINGS","QDKP2_Chron: scheduleRepeating is updating '".. name.."' to time: ".. when);
			else
				QDKP2_Chron_printDebugError("QDKP2_Chron_DEBUG_WARNINGS","QDKP2_Chron: scheduleRepeating is asigning '".. name.."'.");
			end
		end
		QDKP2_ChronData.byName[name] = QDKP2_Chron_getTable();
		namedSchedule = QDKP2_ChronData.byName[name];
		namedSchedule.time = when+GetTime();
		namedSchedule.period = when;
		namedSchedule.handler = handler;
		namedSchedule.repeating = true;
	end
	
	--[[
	--	QDKP2_Chron_flushByName(name, when);
	--
	-- Updates the ByName or Repeating event to flush at the time specified.  If no time is specified flush will be immediate. If it is a Repeating event the timer will be reset.
	--
	--]]
	function QDKP2_Chron_flushByName(name, when)
		if ( not name ) then 
			QDKP2_Chron_printDebugError("QDKP2_Chron_DEBUG_WARNINGS","QDKP2_Chron Error Detection: No name specified to QDKP2_Chron_flushByName");
			return;
		elseif ( not QDKP2_ChronData.byName[name] ) then
			QDKP2_Chron_printDebugError("QDKP2_Chron_DEBUG_WARNINGS","QDKP2_Chron Error Detection: no previous entry found for QDKP2_Chron_flushByName entry '".. name.."'.");
			return;
		end
		if (not when) then
			QDKP2_Chron_printDebugError("QDKP2_Chron_DEBUG_WARNINGS","QDKP2_Chron: flushing '".. name.."'.");
			when = GetTime();
		else
			QDKP2_Chron_printDebugError("QDKP2_Chron_DEBUG_WARNINGS","QDKP2_Chron: flushing '".. name.."' in "..when.." seconds.");
			when = when+GetTime();
		end
		QDKP2_ChronData.byName[name].time = when;
	end

	--[[
	--	QDKP2_Chron_startTimer([ID]);
	--		Starts a timer on a particular
	--
	--	Args
	--		ID - optional parameter to identify who is asking for a timer.
	--		
	--		If ID does not exist, this:GetName() is used. 
	--
	--	When you want to get the amount of time passed since startTimer(ID) is called, 
	--	call getTimer(ID) and it will return the number in seconds. 
	--
	--]]
	function QDKP2_Chron_startTimer( id ) 
		if ( not QDKP2_Chron_online ) then 
			return;
		end

		if ( not id ) then 
			id = this:GetName();
		end

		-- Create a table for this id's timers
		if ( not QDKP2_ChronData.timers[id] ) then
			QDKP2_ChronData.timers[id] = QDKP2_Chron_getTable();
		end

		-- Clear out an entry if the table is too big.
		if (#QDKP2_ChronData.timers[id] > QDKP2_Chron_MAX_TASKS_PER_FRAME) then
			QDKP2_Chron_printError("Too many QDKP2_Chron timers created for id " .. tostring(id));
			return;
		end

		-- Add a new timer entry 
		table.insert(QDKP2_ChronData.timers[id], GetTime());
	end


	--[[
	--	endTimer([id]);
	-- 
	--		Ends the timer and returns the amount of time passed.
	--
	--	args:
	--		id - ID for the timer. If not specified, then ID will
	--		be this:GetName()
	--
	--	returns:
	--		(Number delta, Number start, Number end)
	--
	--		delta - the amount of time passed in seconds.
	--		start - the starting time 
	--		now - the time the endTimer was called.
	--]]

	function QDKP2_Chron_endTimer( id ) 
		if ( not QDKP2_Chron_online ) then 
			return;
		end

		if ( not id ) then 
			id = this:GetName();
		end

		if ( not QDKP2_ChronData.timers[id] or #QDKP2_ChronData.timers[id] == 0) then
			return nil;
		end
	
		local now = GetTime();

		-- Grab the last timer called
		local startTime = tremove(QDKP2_ChronData.timers[id]);

		return (now - startTime), startTime, now;
	end


	--[[
	--	getTimer([id]);
	-- 
	--		Gets the timer and returns the amount of time passed.
	--		Does not terminate the timer.
	--
	--	args:
	--		id - ID for the timer. If not specified, then ID will
	--		be this:GetName()
	--
	--	returns:
	--		(Number delta, Number start, Number end)
	--
	--		delta - the amount of time passed in seconds.
	--		start - the starting time 
	--		now - the time the endTimer was called.
	--]]

	function QDKP2_Chron_getTimer( id ) 
		if ( not QDKP2_Chron_online ) then 
			return;
		end

		if ( not id ) then 
			id = this:GetName();
		end

		local now = GetTime();
		if ( not QDKP2_ChronData.timers[id] or #QDKP2_ChronData.timers[id] == 0) then
			return 0, 0, now;
		end
	
		-- Grab the last timer called
		local startTime = QDKP2_ChronData.timers[id][#QDKP2_ChronData.timers[id]];

		return (now - startTime), startTime, now;
	end
	
	--[[
	--	isTimerActive([id])
	--		returns true if the timer exists. 
	--		
	--	args:
	--		id - ID for the timer. If not specified, then ID will
	--		be this:GetName()
	--
	--	returns:
	--		true - exists
	--		false - does not
	--]]
	function QDKP2_Chron_isTimerActive( id ) 
		if ( not QDKP2_Chron_online ) then 
			return;
		end

		if ( not id ) then 
			id = this:GetName();
		end

		-- Create a table for this id's timers
		if ( not QDKP2_ChronData.timers[id] ) then
			return false;
		end

		return true;
	end

	--[[
	--	getTime()
	--
	--		returns the QDKP2_Chron internal elapsed time.
	--
	--	returns:
	--		(elapsedTime)
	--		
	--		elapsedTime - time in seconds since QDKP2_Chron initialized
	--]]	
	function QDKP2_Chron_getTime() 
		return QDKP2_ChronData.elapsedTime;
	end
	
	--[[
	--	QDKP2_Chron_afterInit(func, ...)
	--		Performs func after the game has truely started.
	--	By Thott
	--]]
	function QDKP2_Chron_afterInit(func, ...)
		local id;
		if(this) then
			id = this:GetName();
		else
			id = "unknown";
		end
		--if(id == "SkyFrame") then
		--	QDKP2_Chron_printError("Ignoring Sky init");
		--	return;
		--end
		if(QDKP2_ChronData.initialized) then
			func(...);
		else
			if(not QDKP2_ChronData.afterInit) then
				QDKP2_ChronData.afterInit = QDKP2_Chron_getTable();
				QDKP2_Chron_schedule(0.2, QDKP2_Chron_initCheck);
			end
			local recTable = QDKP2_Chron_getTable();
			recTable.func = func;
			recTable.args = QDKP2_Chron_getArgTable(...);
			recTable.id = id;
			tinsert(QDKP2_ChronData.afterInit, recTable);
		end
	end
	
	
	------------------------------------------------------------------------------
	--[[ Table Recycling ]]--
	------------------------------------------------------------------------------
	
	function QDKP2_Chron_getTable(...)
		local stack = QDKP2_Chron_tables;
		if (not stack) then
			QDKP2_Chron_tables = {};
			stack = QDKP2_Chron_tables;
			return {};
		end
		local recTable;
		if (#stack >= 1) then
			recTable = tremove(stack)
		else
			recTable = {};
		end
		for i=1, select("#", ...) do
			recTable[i] = select(i, ...);
		end
		return recTable;
	end
	
	-- Release a table to be nilled and used again.
	-- Optionally pass in an unpack(...) as the 2nd arg so that you can return the args:
	-- return QDKP2_Chron_releaseTable(t1, unpack(t1))
	function QDKP2_Chron_releaseTable(t1, ...)
		if (type(t1) ~= "table") then
			return;
		end
		
		local stack = QDKP2_Chron_tables;
		if (not stack) then
			QDKP2_Chron_tables = {};
			stack = QDKP2_Chron_tables;
		end
		
		for k,v in pairs(t1) do
			t1[k] = nil;
		end
		
		tinsert(stack, t1);
		return ...;
	end
	
	
	------------------------------------------------------------------------------
	--[[ Helpers Functions ]]--
	------------------------------------------------------------------------------
	
	function QDKP2_Chron_getArgTable(...)
		if (select('#', ...) == 0) then
			return QDKP2_Chron_emptyTable;
		else
			return QDKP2_Chron_getTable(...);
		end
	end
	
	function QDKP2_Chron_run(func,args)
		if(func) then
			if(args) then
				return func(unpack(args));
			else
				return func();
			end
		end
	end
	
	function QDKP2_Chron_printError(text)
		ChatFrame1:AddMessage(text, RED_FONT_COLOR.r, RED_FONT_COLOR.g, RED_FONT_COLOR.b, 1.0, UIERRORS_HOLD_TIME);
	end
	
	function QDKP2_Chron_printDebugError(var, text)
		if (var) and (getglobal(var)) then
			QDKP2_Chron_printError(text);
		end
	end
	
	------------------------------------------------------------------------------
	--[[ Frame Script Helpers ]]--
	------------------------------------------------------------------------------
	
	function QDKP2_Chron_chatColorsInit()
		QDKP2_ChronData.chatColorsInitialized = true;
		QDKP2_ChronFrame:UnregisterEvent("UPDATE_CHAT_COLOR");
	end
	
	function QDKP2_Chron_initCheck()
		if(not QDKP2_ChronData.initialized) then
			if(UnitName("player") and UnitName("player")~=UKNOWNBEING and UnitName("player")~=UNKNOWNBEING and UnitName("player")~=UNKNOWNOBJECT and QDKP2_ChronData.variablesLoaded and QDKP2_ChronData.enteredWorld and QDKP2_ChronData.chatColorsInitialized) then
				QDKP2_ChronData.initialized = true;
				QDKP2_Chron_schedule(1,QDKP2_Chron_initCheck); 
				return;
			else
				QDKP2_Chron_schedule(0.2,QDKP2_Chron_initCheck); 
				return;
			end
		end
		if(QDKP2_ChronData.afterInit) then
			local i = QDKP2_ChronData.afterInit_i;
			if(not i) then
				i = 1;
			end
			QDKP2_ChronData.afterInit_i = i+1;
			--QDKP2_Chron_printError("afterInit: processing ",i," of ",QDKP2_ChronData.afterInit.n," initialization functions, id: ",QDKP2_ChronData.afterInit[i].id);
			QDKP2_Chron_run(QDKP2_ChronData.afterInit[i].func, QDKP2_ChronData.afterInit[i].args);
			if(i == #QDKP2_ChronData.afterInit) then
				for i,v in ipairs(QDKP2_ChronData.afterInit) do
					QDKP2_Chron_releaseTable(v);
				end
				QDKP2_Chron_releaseTable(QDKP2_ChronData.afterInit);
				QDKP2_ChronData.afterInit = nil;
				QDKP2_ChronData.afterInit_i = nil;
			else
				QDKP2_Chron_schedule(0.1, QDKP2_Chron_initCheck);
				return;
			end
		end
	end
	
	--[[
	--	Sends a chat command through the standard editbox
	--]]
	function QDKP2_Chron_SendChatCommand(command)
		local text = ChatFrameEditBox:GetText();
		ChatFrameEditBox:SetText(command);
		ChatEdit_SendText(ChatFrameEditBox);
		ChatFrameEditBox:SetText(text);
	end
	
	function QDKP2_Chron_RegisterSlashCommands()
		--Needs to be able Variables load if you want to use Sky
		local QDKP2_ChronFunc = function(msg)
			local _,_,seconds,command = string.find(msg,"([%d\.]+)%s+(.*)");
			if(seconds and command) then
				QDKP2_Chron_schedule(seconds,QDKP2_Chron_SendChatCommand,command);
			else
				QDKP2_Chron_printError(SCHEDULE_USAGE1);
				QDKP2_Chron_printError(SCHEDULE_USAGE2);
			end
		end
		if (Satellite) then
			Satellite.registerSlashCommand(
				{
					id = "Schedule";
					commands = SCHEDULE_COMM;
					onExecute = QDKP2_ChronFunc;
					helpText = SCHEDULE_DESC;
					replace = true;
				}
			);
		else
			SlashCmdList["QDKP2_Chron_SCHEDULE"] = QDKP2_ChronFunc;
			for i = 1, #SCHEDULE_COMM do setglobal("SLASH_QDKP2_Chron_SCHEDULE"..i, SCHEDULE_COMM[i]); end
		end
	end
	
	------------------------------------------------------------------------------
	--[[ Frame Scripts ]]--
	------------------------------------------------------------------------------
	
	function QDKP2_Chron_OnLoad()
		QDKP2_Chron_framecount = 0;
		
		if (not QDKP2_ChronData.byName) then
			QDKP2_ChronData.byName = {};
		end
		if (not QDKP2_ChronData.repeating) then
			QDKP2_ChronData.repeating = {};
		end
		if (not QDKP2_ChronData.sched) then
			QDKP2_ChronData.sched = {};
		end
		QDKP2_ChronData.elapsedTime = 0;
		
		--QDKP2_Chron_afterInit(QDKP2_Chron_RegisterSlashCommands);
	end
	
	function QDKP2_Chron_OnEvent()
		if(event == "VARIABLES_LOADED") then
			QDKP2_ChronData.variablesLoaded = true;
			QDKP2_ChronFrame:Show();
		elseif (event == "PLAYER_ENTERING_WORLD") then
			QDKP2_ChronData.enteredWorld = true;
			QDKP2_Chron_online = true;
		elseif (event == "PLAYER_LEAVING_WORLD") then
			QDKP2_Chron_online = false;
		elseif ( event == "UPDATE_CHAT_COLOR" ) then
			QDKP2_Chron_scheduleByName("QDKP2_ChronAfterChatColorInit", 1, QDKP2_Chron_chatColorsInit);
		end	
	end
	
	function QDKP2_Chron_OnUpdate_Quick()
		if ( not QDKP2_Chron_online ) then 
			return;
		end
		if ( not QDKP2_ChronData.variablesLoaded ) then 
			return;
		end
		
		if ( QDKP2_ChronData.elapsedTime ) then
			QDKP2_ChronData.elapsedTime = QDKP2_ChronData.elapsedTime + arg1;
		else
			QDKP2_ChronData.elapsedTime = arg1;
		end
		
		-- Execute scheduled tasks that are ready, pulling them off the front of the list queue.
		local now = GetTime();
		local i;
		local task;
		while(#QDKP2_ChronData.sched > 0) do
			if (not QDKP2_ChronData.sched[1].time) then
				Sea.io.printTable(QDKP2_ChronData.sched[1]);
				tremove(QDKP2_ChronData.sched, 1);
			elseif(QDKP2_ChronData.sched[1].time <= now) then
				task = tremove(QDKP2_ChronData.sched, 1);
				QDKP2_Chron_run(task.handler, task.args);
				QDKP2_Chron_releaseTable(task);
			else
				break;
			end
		end
		
		-- Execute named scheduled tasks that are ready.
		local k,v = next(QDKP2_ChronData.byName);
		local newK, newV;
		while (k ~= nil) do
			newK,newV = next(QDKP2_ChronData.byName, k);
			if (not v.time) then
				Sea.io.printTable(v);
				QDKP2_ChronData.byName[k] = nil;
			elseif (v.time <= now) then
				if (v.repeating) then
					QDKP2_ChronData.byName[k].time = now + v.period;
					v.handler();
				else
					QDKP2_Chron_run(v.handler, v.args);
					QDKP2_Chron_releaseTable(QDKP2_ChronData.byName[k]);
					QDKP2_ChronData.byName[k] = nil;
				end
			end
			k,v = newK,newV;
		end
	end
	
	function QDKP2_Chron_OnUpdate_Debug()
		if ( not QDKP2_Chron_online ) then 
			return;
		end
		if ( not QDKP2_ChronData.variablesLoaded ) then 
			return;
		end
		local memstart = collectgarbage("count");
		
		if ( QDKP2_ChronData.elapsedTime ) then
			QDKP2_ChronData.elapsedTime = QDKP2_ChronData.elapsedTime + arg1;
		else
			QDKP2_ChronData.elapsedTime = arg1;
		end
	
		local now = GetTime();
		local i;
		local task;
		-- Execute scheduled tasks that are ready, popping them off the heap.
		while(#QDKP2_ChronData.sched > 0) do
			if(QDKP2_ChronData.sched[1].time <= now) then
				task = tremove(QDKP2_ChronData.sched, 1);
				QDKP2_Chron_run(task.handler, task.args);
				QDKP2_Chron_releaseTable(task);
			else
				break;
			end
		end
		
		local memend = collectgarbage("count");
		if(memend - memstart > 0) then
			QDKP2_Chron_printError("gcmemleak from QDKP2_ChronData.sched in OnUpdate: "..(memend - memstart));
		end
		
		-- Execute named scheduled tasks that are ready.
		memstart = memend;
		local k,v = next(QDKP2_ChronData.byName);
		local newK, newV;
		while (k ~= nil) do
			newK,newV = next(QDKP2_ChronData.byName, k);
			if(v.time <= now) then
				local m = collectgarbage("count");
				if (v.repeating) then
					QDKP2_ChronData.byName[k].time = now + v.period;
					v.handler();
				else
					QDKP2_Chron_run(v.handler, v.args);
					QDKP2_Chron_releaseTable(QDKP2_ChronData.byName[k]);
					QDKP2_ChronData.byName[k] = nil;
				end
				local mm = collectgarbage("count");
				memstart = memstart + mm - m;
			end
			k,v = newK,newV;
		end
		
		memend = collectgarbage("count");
		if(memend - memstart > 0) then
			QDKP2_Chron_printError("gcmemleak from QDKP2_ChronData.byName in OnUpdate: "..(memend - memstart));
		end
	end
	
	------------------------------------------------------------------------------
	--[[ Frame Script Assignment ]]--
	------------------------------------------------------------------------------
	
	--Event Driver
	if (not QDKP2_ChronFrame) then
		CreateFrame("Frame", "QDKP2_ChronFrame");
	end
	QDKP2_ChronFrame:Hide();
	--Event Registration
	QDKP2_ChronFrame:RegisterEvent("VARIABLES_LOADED");
	QDKP2_ChronFrame:RegisterEvent("PLAYER_ENTERING_WORLD");
	QDKP2_ChronFrame:RegisterEvent("PLAYER_LEAVING_WORLD");
	QDKP2_ChronFrame:RegisterEvent("UPDATE_CHAT_COLOR");
	--Frame Scripts
	QDKP2_ChronFrame:SetScript("OnEvent", QDKP2_Chron_OnEvent);
	QDKP2_ChronFrame:SetScript("OnUpdate", QDKP2_Chron_OnUpdate_Quick);
	--OnLoad Call
	QDKP2_Chron_OnLoad();
  
end

