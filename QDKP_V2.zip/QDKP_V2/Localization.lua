
--General
QDKP2_LOC_Player="player"
QDKP2_LOC_Net="Net"
QDKP2_LOC_Spent="Spent"
QDKP2_LOC_Total="Total"
QDKP2_LOC_Hours="Hours"

--Warnings
QDKP2_LOC_NotIntoARaid="You are not into a Raid"
QDKP2_LOC_BetaWarning="You are running a beta version of QDKP2.\nIf you find a bug, please mail me the error\n message (if any) and how you got that bug\n at contact@belloli.net."
QDKP2_LOC_BecomedNegative="$NAME's net DKP amount has becomed negative."
QDKP2_LOC_Negative="$NAME's net DKP amount is negative."

--Auto Boss Award
QDKP2_LOC_ChatKilledTrig="(.+) dies."
QDKP2_LOC_Killed="$MOB has been killed!"
QDKP2_LOC_Kill=" kill" --used in the reason of DKP awarding (like 'gains 10 dkp for Onyxia _kill_

--Winners Detection System
QDKP2_LOC_WinDetect_Q="Do you want to turn on\nthe Winner Detect System?"
QDKP2_LOC_ChatLootTrig="([^%s]+) receives loot: (.+)%."
QDKP2_LOC_ChatMeLootTrig="You receive loot: (.+)%."
QDKP2_LOC_Loots="Loots"
QDKP2_LOC_NoRarityInfo="Cannot find rarity info for $ITEM"

--Raid Manager
QDKP2_LOC_IsInRaid="Is in the raid just joined"
QDKP2_LOC_JoinsRaid="Joins the Raid"
QDKP2_LOC_GoesOnline="Returns Online"
QDKP2_LOC_GoesOffline="Goes Offline"
QDKP2_LOC_IsOffline="Is Offline"
QDKP2_LOC_NoInGuild="$NAMES don't seem to be in guild. Skipped."
QDKP2_LOC_LeavedRaid="Leaved the Raid"

--Ironman Bonus
QDKP2_LOC_Start="Start"
QDKP2_LOC_Finish="Finish"
QDKP2_LOC_FinishWithRaid="The IronMan Bonus has not been closed yet.\nDo you want to close it now?"
QDKP2_LOC_StartButOffline="IronMan bonus started but player is offline."
QDKP2_LOC_IronmanMarkPlaced="IronMan mark placed."
QDKP2_LOC_DataWiped="IronMan Data has been Wiped."

--notify
QDKP2_LOC_NotifyString="You Have $NET DKP. ($RAIDGAINED gained and $RAIDSPENT spent in this raid)." --also available $RANK and $GUILDNAME

--raid award
QDKP2_LOC_OfflineNoAwReas="Offline. Does not awards $AMOUNT DKP for $REASON."
QDKP2_LOC_OfflineNoAw="Offline. Does not awards $AMOUNT DKP."
QDKP2_LOC_NoRankReas="UnDKP-able Rank. Does not awards $AMOUNT DKP for $REASON."
QDKP2_LOC_NoRank="UnDKP-able Rank. Does not awards $AMOUNT DKP."
QDKP2_LOC_ReceivedReas="Online Raid members received $AMOUNT DKP for $REASON."
QDKP2_LOC_Received="Online Raid members received $AMOUNT DKP."

--timer
QDKP2_LOC_TimerTick="timer tick"
QDKP2_LOC_IntegerTime="integer raiding time"
QDKP2_LOC_LosesOffline="Loses Timer tick because was Offline."
QDKP2_LOC_RaidTimerLog="Timer tick. Online Raid members awards $TIME hours."
QDKP2_LOC_HoursUpdted="Hours Updated"
QDKP2_LOC_TimerStop="Timer stopped"
QDKP2_LOC_TimerResumed="Timer resumed"
QDKP2_LOC_TimerStarted="Timer started"

--upload
QDKP2_LOC_NoMod="No DKP modification have been done since last download/upload."
QDKP2_LOC_Successful="Upload report: $UPLOADED notes sent. Wait for check (In $TIME seconds)..."
QDKP2_LOC_Failed="Upload report: $FAILED haven't been successfull uploaded. Try again in few seconds."
QDKP2_LOC_IndexNoFound="$NAME's guild index cannot be found, skipped. Try again in a minute."
QDKP2_LOC_IndexNoFoundLog="Has a broken guild cache index (Upload Failed)"

--download
QDKP2_LOC_NewSessionQ="Enter the name of the New Session"
QDKP2_LOC_DifferentTot="$NAME's net+spent is different from the total. Please check."
