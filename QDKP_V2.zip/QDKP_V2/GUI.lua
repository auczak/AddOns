
-- Copyright 2006 Riccardo Belloli & Lemon Jello & Stormm
-- This file is a part of QDKP_V2 (see QDKP_V2.lua)
--                    ## GUI FUNCTIONS ##

------------------------------GUI Constants----------------------------------------

QDKP2_dkpAwardRaid = 0
QDKP2_dkpPerHour = 0
QDKP2_numFrame2entries = 20
QDKP2log_show = ""
QDKP2_numFrame5entries = 25
QDKP2_numRaidOnLastUpdate=0
QDKP2_ListIndex = 1
QDKP2_LogIndex = 1
QDKP2totalIndex = 1
QDKP2totalIndexName = ""
QDKP2_FramesOpen = {}
QDKP2_Order="Alpha"


------------------------------------- INIT ----------------------------------
function QDKP2_GUI_Init()
end

------------------------------------- ON LOAD ----------------------------------------
function QDKP2_GUI_OnLoad()
  if QDKP2ironMan_time ~= 0 then
    QDKP2frame1_ironman:SetText("Finish")
  end
  QDKP2_frame1_dkpAwardRaidSet(QDKP2_dkpAwardRaid)
  QDKP2_frame1_dkpPerHourSet(QDKP2_dkpPerHour)
  QDKP2_RefreshAll()
end

----------------------------------------TOGGLES------------------------
--Brings up popup GUI
function QDKP2_Toggle_Main(showFrame) --showFrame is optional
  QDKP2_Toggle(1,onoff)
end

---------------------------------------

--Toggles the quickbutton frame (frame0) from moveable to non moveable and visa versa
function QDKP2_ToggleMoveable()
	if(QDKP2_QuickButton:IsMovable()) then
		QDKP2_QuickButton:SetMovable(false);
	else
		QDKP2_QuickButton:SetMovable(true);
	end
end

---------------------------------------

--toggles it so that it will hide windows past closed window, but shows them if that one is opened again
function QDKP2_SmartToggle(toggleFrame)
  QDKP2_SetLootCharge(nil)
	if(QDKP2_FramesOpen[toggleFrame]) then
		QDKP2_FramesOpen[toggleFrame]=false
	else
		QDKP2_FramesOpen[toggleFrame]=true
	end
	
	for i=1, 6 do
		local incFrame = getglobal("QDKP2_Frame"..i)
		if(QDKP2_FramesOpen[i]) then
			incFrame:Show()
		else
			incFrame:Hide()
		end
	end
end


--toggles target frame.. secondvar is optional
function QDKP2_Toggle(frameNum, showFrame)
  QDKP2_SetLootCharge(nil)
	local incFrame = getglobal("QDKP2_Frame"..frameNum)
	if incFrame then
		if showFrame==true then
			incFrame:Show();
			QDKP2_FramesOpen[frameNum] = true
		elseif showFrame==false then
			incFrame:Hide();
			QDKP2_FramesOpen[frameNum] = false
		else
			if incFrame:IsVisible() then
				incFrame:Hide();
				QDKP2_FramesOpen[frameNum] = false
			else
				incFrame:Show();
				QDKP2_FramesOpen[frameNum] = true
			end
		end
	end
end

---------------------------------------

--Toglges all frames after index off, but only first on
function QDKP2_ToggleOffAfter(index)
    
    QDKP2_SetLootCharge(nil)
    if index==1 then
        QDKP2_RefreshBackupTime()
    end
  
    if index==2 and GetNumGuildMembers(true)<1 then
        GuildRoster()
    end
	local temp = getglobal("QDKP2_Frame"..index)
	local isOn = false
	
    if( temp:IsVisible() ) then
		isOn = true
        local incFrame = getglobal("QDKP2_Frame"..index)
		incFrame:Hide();
	else
		local incFrame = getglobal("QDKP2_Frame"..index)
		incFrame:Show();
	end 
  
    if index <= 1 and isOn then
        QDKP2totalIndexName = ""
        QDKP2_Frame5:Hide()
        QDKP2_Frame6:Hide()
    end
    
    if index == 5 and isOn then
        QDKP2_Frame5:Hide()
        QDKP2_Frame6:Hide()
    end
	
    for i=index, 4 do
		local incFrame = getglobal("QDKP2_Frame"..i)
		if(isOn == true ) then
			incFrame:Hide();
		end
		
	end
end

---------------------------------------

--Toggles all frames after index off/on
function QDKP2_ToggleAfter(index)
  QDKP2_SetLootCharge(nil)
	local temp = getglobal("QDKP2_Frame"..index)
	local isOn = false
	if(temp:IsVisible() ) then
		isOn = true
        local incFrame = getglobal("QDKP2_Frame"..index)
		incFrame:Hide();
	else
    local incFrame = getglobal("QDKP2_Frame"..index)
		incFrame:Show();
	end
  if index <= 1 and isOn then
    QDKP2totalIndexName = ""
    QDKP2_Frame5:Hide()
    QDKP2_Frame6:Hide()
    QDKP2_ReportBox:Hide()
  end
  if index == 5 and isOn then
    QDKP2_Frame5:Hide()
    QDKP2_Frame6:Hide()
    QDKP2_ReportBox:Hide()
  end
	for i=index, 4 do
		local incFrame = getglobal("QDKP2_Frame"..i)
		if(isOn == true ) then
			incFrame:Hide();
		else
			incFrame:Show();
		end
		
	end
end

---------------------------------------

-- Drop Down Menu for Selecting Raid / Guild / Bidders

function QDKP2_DropDownMenu_OnShow()
    UIDropDownMenu_Initialize(this, QDKP2_DropDownMenu_Initialize);	 
    UIDropDownMenu_SetWidth(140);
    if QDKP2_DropDownMenu_ID == nil then
        UIDropDownMenu_SetSelectedID(QDKP2_DropDownMenu, 1);
    end
end

function QDKP2_DropDownMenu_Initialize()
    for k, v in pairs(QDKP2_DropDownMenu_TEMPLATES) do
		local info = {};
		info.text = QDKP2_DropDownMenu_TEMPLATES[k];
		info.func = QDKP2_DropDownMenu_OnClick;
		UIDropDownMenu_AddButton(info);
	end
end

function QDKP2_DropDownMenu_OnClick()
    
    local BidResetButton = getglobal("QDKP2frame2_BidReset")
    BidResetButton:Hide()
    
    QDKP2_ListIndex = 1
	QDKP2totalIndex = 1
	QDKP2totalIndexName =""
    
    QDKP2_DropDownMenu_ID = this:GetID();
    UIDropDownMenu_SetSelectedID(QDKP2_DropDownMenu, QDKP2_DropDownMenu_ID);
    selection = this:GetText()
--  DEFAULT_CHAT_FRAME:AddMessage("User selected : " .. selection)
    if QDKP2_DropDownMenu_ID == 1 then
        
    --  QDKP2_ShowAllGuild = false
    elseif QDKP2_DropDownMenu_ID == 2 then
        
    --  QDKP2_ShowAllGuild = true
    else
        BidResetButton:Show()
--      DEFAULT_CHAT_FRAME:AddMessage("Do " .. selection)
    end
    QDKP2_RefreshRoster()
end
--[[
function QDKP2_AllGuildCheckButtonSet(todo)
	QDKP2_ListIndex = 1
	QDKP2totalIndex = 1
	QDKP2totalIndexName =""
	
  if todo=="toggle" then
    if(QDKP2frame2_guildCheckButton:GetChecked()==1) then
      QDKP2_ShowAllGuild = true
    else
      QDKP2_ShowAllGuild = false
    end
  elseif todo=="on" then
    QDKP2_ShowAllGuild = true
    QDKP2frame2_guildCheckButton:SetChecked(1)
  elseif todo=="off" then
    QDKP2_ShowAllGuild = false
    QDKP2frame2_guildCheckButton:SetChecked(0)
  end
  
	QDKP2_RefreshRoster()
  
end
--]]
function QDKP2_AutoAddMobSet(todo)
  if todo == "toggle" then  
    if (QDKP2frame1_UseMobEditor:GetChecked()==1) then
      QDKP2_AddMobOption = true
      QDKP2_Msg(QDKP2_COLOR_YELLOW.."Mod Editor mode enabled")
    else
      QDKP2_AddMobOption = false
      QDKP2_Msg(QDKP2_COLOR_YELLOW.."Mod Editor mode disabled")
    end
  elseif todo == "on" then
    QDKP2_AddMobOption = true
    QDKP2frame1_UseMobEditor:SetChecked(1)
    QDKP2_Msg(QDKP2_COLOR_YELLOW.."Mod Editor mode enabled")
  elseif todo == "off" then
    QDKP2_AddMobOption = false
    QDKP2frame1_UseMobEditor:SetChecked(0)
    QDKP2_Msg(QDKP2_COLOR_YELLOW.."Mod Editor mode disabled")
  end
end

function QDKP2_AutoBossEarnSet(todo)
  if todo == "toggle" then  
    if (QDKP2frame1_UseBossMod:GetChecked()==1) then
      QDKP2_AutoBossEarn = true
      QDKP2_Msg(QDKP2_COLOR_YELLOW.."Auto Boss Award enabled")
    else
      QDKP2_AutoBossEarn = false
      QDKP2_Msg(QDKP2_COLOR_YELLOW.."Auto Boss Award disabled")
    end
  elseif todo == "on" then
    QDKP2_AutoBossEarn = true
    QDKP2frame1_UseBossMod:SetChecked(1)
    QDKP2_Msg(QDKP2_COLOR_YELLOW.."Auto Boss Award enabled")
  elseif todo == "off" then
    QDKP2_AutoBossEarn = false
    QDKP2frame1_UseBossMod:SetChecked(0)
    QDKP2_Msg(QDKP2_COLOR_YELLOW.."Auto Boss Award disabled")
  end
end

function QDKP2_DetectLootSet(todo)
  if todo == "toggle" then  
    if (QDKP2frame1_DetectLoot:GetChecked()==1) then
      QDKP2_DetectLoot = true
      QDKP2_Msg(QDKP2_COLOR_YELLOW.."Loot Detection enabled")
    else
      QDKP2_DetectLoot = false
      QDKP2_Msg(QDKP2_COLOR_YELLOW.."Loot Detection disabled")
    end
  elseif todo == "on" then
    QDKP2_DetectLoot = true
    QDKP2frame1_DetectLoot:SetChecked(1)
    QDKP2_Msg(QDKP2_COLOR_YELLOW.."Loot Detection enabled")
  elseif todo == "off" then
    QDKP2_DetectLoot = false
    QDKP2frame1_DetectLoot:SetChecked(0)
    QDKP2_Msg(QDKP2_COLOR_YELLOW.."Loot Detection disabled")
  end
end
------------------------------------SCROLL UP/DOWN-------------

--function moves the list up and down
--[[
function QDKP2_ScrollList(inc)
  DEFAULT_CHAT_FRAME:AddMessage("QDKP2_Scrolllist called.")
  local numEntries
	if(QDKP2_ShowAllGuild) then			--checks which list and ordinate it
        QDKP2name=QDKP2_SortList(QDKP2name)
        numEntries = table.getn(QDKP2name)
	else
        QDKP2raid=QDKP2_SortList(QDKP2raid)
        numEntries = table.getn(QDKP2raid)
	end
  if numEntries>0 then
    if(inc == "+")then
      QDKP2_ListIndex = QDKP2_ListIndex + 10
    elseif (inc == "-") then
      QDKP2_ListIndex = QDKP2_ListIndex - 10
    else
      QDKP2_ListIndex = QDKP2_ListIndex + inc
    end
  
    if QDKP2_ListIndex < 1 then QDKP2_ListIndex = 1; end
    if QDKP2_ListIndex > numEntries then QDKP2_ListIndex = numEntries; end

    QDKP2_RefreshRoster()  -- refreshes the change
  end
end
--]]

function QDKP2_ScrollList_Log(inc)

  local numEntr = 1
  if QDKP2log[QDKP2log_show] then
    numEntr = table.getn(QDKP2log[QDKP2log_show])
  end

	if(inc == "+")then
		QDKP2_LogIndex = QDKP2_LogIndex + 10
	elseif (inc == "-") then
    QDKP2_LogIndex = QDKP2_LogIndex - 10
  elseif(inc == "top")then
    QDKP2_LogIndex = 1
  elseif(inc == "bottom")then
    if numentr > 20 then
      QDKP2_LogIndex = numEntr - 10
    end
  else
    QDKP2_LogIndex = QDKP2_LogIndex + inc
  end

  if QDKP2_LogIndex < 1 then QDKP2_LogIndex = 1; end
  if QDKP2_LogIndex > numEntr then QDKP2_LogIndex = numEntr; end
  
	QDKP2_RefreshLog()  -- refreshes the change
end
 

------------------------------------------REFRESHES---------

--function adds people that are in the raid and in the guild to the list.



function QDKP2_FindLeavers(name,leaved)
  if leaved then
    QDKP2log_Entry(name, "Leaved the raid", QDKP2LOG_LEAVED)
  end
end
---------------------------------------

function QDKP2_RefreshAll()
  QDKP2_RefreshRoster()
  QDKP2_RefreshLog()
end

---------------------------------------

--Refreshes the roster window
function QDKP2_RefreshRoster()
    
    local tempFrame = getglobal("QDKP2_Frame2")
    if (tempFrame:IsVisible() ) then
--      DEFAULT_CHAT_FRAME:AddMessage("Frame2 is visible. Function should be called.")
    else
--      DEFAULT_CHAT_FRAME:AddMessage("Frame2 not visible. Function should not be called")
        return
    end
    
    local numEntries
    
    if QDKP2_DropDownMenu_ID == 2 then			--checks which list and ordinate it
        QDKP2name = QDKP2_SortList(QDKP2name)
        numEntries = table.getn(QDKP2name)
    elseif QDKP2_DropDownMenu_ID == 3 then
        QDKP2bidders = QDKP2_SortList(QDKP2bidders)
        numEntries = table.getn(QDKP2bidders)
--      DEFAULT_CHAT_FRAME:AddMessage("QDKP2_DropDownMenu_ID = " .. QDKP2_DropDownMenu_ID)
    else
        QDKP2raid = QDKP2_SortList(QDKP2raid)
        numEntries = table.getn(QDKP2raid)
	end
    
    FauxScrollFrame_Update(QDKP2_Frame2ScrollBar, numEntries, QDKP2_numFrame2entries, 50)  -- QDKP2_numFrame2entries = 20
	
	for i=1, QDKP2_numFrame2entries do  --fills in the list data
		QDKP2_ListIndex = i + FauxScrollFrame_GetOffset(QDKP2_Frame2ScrollBar)
    
		local r	= 1
		local g = 1
		local b = 1
		local a = 1
               
--      getglobal("QDKP2_frame2_entry"..i.."_name"):SetVertexColor(r, g, b, a)
		getglobal("QDKP2_frame2_entry"..i.."_rank"):SetVertexColor(r, g, b, a)
--		getglobal("QDKP2_frame2_entry"..i.."_class"):SetVertexColor(r, g, b, a)
		getglobal("QDKP2_frame2_entry"..i.."_net"):SetVertexColor(r, g, b, a)
		getglobal("QDKP2_frame2_entry"..i.."_total"):SetVertexColor(r, g, b, a)
		getglobal("QDKP2_frame2_entry"..i.."_spent"):SetVertexColor(r, g, b, a)
		getglobal("QDKP2_frame2_entry"..i.."_hours"):SetVertexColor(r, g, b, a)
		getglobal("QDKP2_frame2_entry"..i.."_deltatotal"):SetVertexColor(r, g, b, a)
		getglobal("QDKP2_frame2_entry"..i.."_deltaspent"):SetVertexColor(r, g, b, a)
		getglobal("QDKP2_frame2_entry"..i.."_deltahours"):SetVertexColor(r, g, b, a)

		if (QDKP2_ListIndex < numEntries + 1) then
            local tempName 
            if(QDKP2_DropDownMenu_ID == 2) then			--checks which list and ordinate it
                tempName=QDKP2name[QDKP2_ListIndex]
            elseif (QDKP2_DropDownMenu_ID == 3) then
                tempName=QDKP2bidders[QDKP2_ListIndex]
            else
                tempName=QDKP2raid[QDKP2_ListIndex]
            end
      
            local ModifyColor = false
            if QDKP2_IsModified(tempName) then
                r=0.27
                g=0.92
                b=1
                a=1
                ModifyColor = true
            end
      
            if tempName == QDKP2totalIndexName then
                a=0.7
                ModifyColor = true
            end
      
            if ModifyColor then
                getglobal("QDKP2_frame2_entry"..i.."_name"):SetVertexColor(r, g, b, a)
                getglobal("QDKP2_frame2_entry"..i.."_rank"):SetVertexColor(r, g, b, a)
                getglobal("QDKP2_frame2_entry"..i.."_class"):SetVertexColor(r, g, b, a)
                getglobal("QDKP2_frame2_entry"..i.."_net"):SetVertexColor(r, g, b, a)
                getglobal("QDKP2_frame2_entry"..i.."_total"):SetVertexColor(r, g, b, a)
                getglobal("QDKP2_frame2_entry"..i.."_spent"):SetVertexColor(r, g, b, a)
                getglobal("QDKP2_frame2_entry"..i.."_hours"):SetVertexColor(r, g, b, a)
                getglobal("QDKP2_frame2_entry"..i.."_deltatotal"):SetVertexColor(r, g, b, a)
                getglobal("QDKP2_frame2_entry"..i.."_deltaspent"):SetVertexColor(r, g, b, a)
                getglobal("QDKP2_frame2_entry"..i.."_deltahours"):SetVertexColor(r, g, b, a)
            end
            
            -- Added to show class colors
            
            r, g, b, a = GetClassRGB(QDKP2class[tempName])
            getglobal("QDKP2_frame2_entry"..i.."_name"):SetVertexColor(r, g, b, a)
            getglobal("QDKP2_frame2_entry"..i.."_class"):SetVertexColor(r, g, b, a)
			
            getglobal("QDKP2_frame2_entry"..i.."_name"):SetText(tempName);
			getglobal("QDKP2_frame2_entry"..i.."_rank"):SetText(QDKP2rank[tempName]);
            getglobal("QDKP2_frame2_entry"..i.."_class"):SetText(QDKP2class[tempName]);
			local outNet = QDKP2noteTotal[tempName] - QDKP2noteSpent[tempName]
			getglobal("QDKP2_frame2_entry"..i.."_net"):SetText(outNet);
			getglobal("QDKP2_frame2_entry"..i.."_total"):SetText(QDKP2noteTotal[tempName]);
			getglobal("QDKP2_frame2_entry"..i.."_spent"):SetText(QDKP2noteSpent[tempName]);
			
            -- Modified entry for EPGP Ratio Display
            
            if QDKP2_RATIO_RANK[QDKP2rank[tempName]] then 
                if QDKP2noteSpent[tempName] ~= 0 then
                    QDKP2ratio = QDKP2noteTotal[tempName] / QDKP2noteSpent[tempName];
                else
                    QDKP2ratio = QDKP2noteTotal[tempName];
                end
            else    
                QDKP2ratio = 0;
            end
            
            getglobal("QDKP2_frame2_entry"..i.."_ratio"):SetJustifyH("RIGHT");
            getglobal("QDKP2_frame2_entry"..i.."_ratio"):SetText(string.format("%8.3f",QDKP2ratio));
            
            -- End of added entry for EPGP Ratio Display
            
            getglobal("QDKP2_frame2_entry"..i.."_hours"):SetText(string.format("%5.1f",QDKP2noteHours[tempName]));
			getglobal("QDKP2_frame2_entry"..i.."_deltatotal"):SetText(QDKP2gained[tempName]);
			getglobal("QDKP2_frame2_entry"..i.."_deltaspent"):SetText(QDKP2spent[tempName]);
			getglobal("QDKP2_frame2_entry"..i.."_deltahours"):SetText(QDKP2hours[tempName]);
      
			getglobal("QDKP2_frame2_entry"..i):Show();
		else
			getglobal("QDKP2_frame2_entry"..i):Hide();
		end
	end
    local totalsText = "Raid "..table.getn(QDKP2raid).." / Guild "..table.getn(QDKP2name)
	QDKP2_Frame2_totals:SetText(totalsText);
    
end


function QDKP2_RefreshLog()

  local Log = QDKP2log[QDKP2log_show]
    
  if not Log then Log = {}; end
    
  local numEntries = table.getn(Log)
	
	for i=1, QDKP2_numFrame5entries do  --fills in the list data
		local indexAt = QDKP2_LogIndex-1+i  --minus one to offset the +i which is also indexed at 1
    
		local r		--sets the colors
		local g
		local b
		local a
    

    r=1
    g=0
    b=0
    a=1

		getglobal("QDKP2_frame5_entry"..i.."_date"):SetVertexColor(r, g, b, a)
    getglobal("QDKP2_frame5_entry"..i.."_net"):SetVertexColor(r, g, b, a)
    getglobal("QDKP2_frame5_entry"..i.."_mod"):SetVertexColor(r, g, b, a)
		getglobal("QDKP2_frame5_entry"..i.."_action"):SetVertexColor(r, g, b, a)
    
		if (indexAt <= numEntries) then
      local LogEntry = Log[indexAt]
      local Type = LogEntry[QDKP2LOG_TYPE]
      
      if Type==QDKP2LOG_CONFIRMED then
        r=0.3
        g=1
        b=0.3
        a=1
      elseif Type==QDKP2LOG_JOINED or Type==QDKP2LOG_LEAVED then
        r=1
        g=0.66
        b=0.4
        a=1
      elseif Type == QDKP2LOG_CRITICAL then
        r=1
        g=0.3
        b=0.3
        a=1
      elseif Type == QDKP2LOG_MODIFY then
        r=0.4
        g=1
        b=1
        a=1      
      elseif Type == QDKP2LOG_NEWSESSION then
        r=0.4
        g=0.4
        b=1
        a=1
      elseif Type == QDKP2LOG_LOST or Type == QDKP2LOG_ABORTED then
        r=0.6
        g=0.6
        b=0.6
        a=1
      elseif Type == QDKP2LOG_LOOT then
        r=1
        g=1
        b=0
        a=1
      elseif Type == QDKP2LOG_EVENT or Type == QDKP2LOG_LOOTLINK then
        r=1
        g=1
        b=1
        a=1
      elseif Type==QDKP2LOG_OFFLINE then
        r=0.9
        g=0.8
        b=0.8
        a=1
      end
      
      if QDKP2_SelectedLogIndex == indexAt then
        a=0.7
      end
      
      getglobal("QDKP2_frame5_entry"..i.."_date"):SetVertexColor(r, g, b, a)
      getglobal("QDKP2_frame5_entry"..i.."_action"):SetVertexColor(r, g, b, a)
      local netto = Log[indexAt][QDKP2LOG_NET]
      if netto then
        if tonumber(netto) < 0 then
          r=1
          g=0.3
          b=0.3
          a=1
        end
      end
      
      getglobal("QDKP2_frame5_entry"..i.."_net"):SetVertexColor(r, g, b, a)
      
      local change = Log[indexAt][QDKP2LOG_CHANGE]
      if change then
        if Type == QDKP2LOG_LOST or Type == QDKP2LOG_ABORTED then
          r=0.6
          g=0.6
          b=0.6
          a=1
        elseif tonumber(change) > 0 then
          r=0
          g=1
          b=0
          a=1
        elseif tonumber(change) < 0 then
          r=1
          g=0.3
          b=0.3
          a=1
        else
          r=1
          g=1
          b=1
          a=1
        end
      end
      getglobal("QDKP2_frame5_entry"..i.."_mod"):SetVertexColor(r, g, b, a)
      
      local datestring = QDKP2log_GetModEntryDateTime(LogEntry)
      
      getglobal("QDKP2_frame5_entry"..i.."_date"):SetText(datestring);
      if LogEntry[QDKP2LOG_NET] then
        getglobal("QDKP2_frame5_entry"..i.."_net"):SetText(LogEntry[QDKP2LOG_NET]);
      else
        getglobal("QDKP2_frame5_entry"..i.."_net"):SetText("")
      end
      if LogEntry[QDKP2LOG_CHANGE] then
        getglobal("QDKP2_frame5_entry"..i.."_mod"):SetText(LogEntry[QDKP2LOG_CHANGE]);
      else
        getglobal("QDKP2_frame5_entry"..i.."_mod"):SetText("");
      end
      
      local description = QDKP2log_GetModEntryText(LogEntry)
      
			getglobal("QDKP2_frame5_entry"..i.."_action"):SetText(description);
      
			getglobal("QDKP2_frame5_entry"..i):Show();
		else
			getglobal("QDKP2_frame5_entry"..i):Hide();
		end
	end
  
  QDKP2frame5_log:SetText(QDKP2log_show .. " Log")
  
  if QDKP2log[QDKP2log_show] then
    if QDKP2log[QDKP2log_show][QDKP2_SelectedLogIndex] then
      local SelectedType = QDKP2log[QDKP2log_show][QDKP2_SelectedLogIndex][QDKP2LOG_TYPE]
      if QDKP2_IsDeletedEntry(SelectedType) then    
        QDKP2Frame6_Delete:SetText("UnDelete")
      else
        QDKP2Frame6_Delete:SetText("Delete Entry")
      end
    end
  end
	--local totalsText = "Raid "..table.getn(QDKP2raid).." / Guild "..table.getn(QDKP2name)
	--getglobal("QDKP2_Frame2_totals"):SetText(totalsText);
end

-----------------------------------------ON CLICK--------

function QDKP2_OpenReport(arg1)
	local buttonName = this:GetName()
	local indexFromButton = 0
	
  local LogList = {}
  
  if QDKP2log[QDKP2log_show] then
    LogList = QDKP2log[QDKP2log_show]
  end
  
	for i=1, QDKP2_numFrame5entries do
		local button = "QDKP2_frame5_entry"..i
		if(buttonName==button) then
			indexFromButton = i
		end
	end
  local x,y = GetCursorPosition()
  QDKP2_ReportBox:SetPoint("TOPLEFT", "UIParent", "BOTTOMLEFT" , x+100, y+45);
  QDKP2_ReportBox:Show()
  QDKP2_ReportName = QDKP2log_show
  QDKP2_ReportIndex = indexFromButton + QDKP2_LogIndex - 1
  QDKP2_SelectedLogIndex = QDKP2_ReportIndex
  QDKP2_Frame6:Hide()
  QDKP2_RefreshLog()
end

function QDKP2_OpenLog(arg1)
	local _, _, guildRankIndex = GetGuildInfo("player");
    if (guildRankIndex == 1) or (guildRankIndex == 0) then
        local buttonName = this:GetName()
        local indexFromButton = 0
        local tableList = QDKP2_RaidorGuildList()
        for i=1, QDKP2_numFrame2entries do
            local button = "QDKP2_frame2_entry"..i
            if(buttonName==button) then
                indexFromButton = i
            end
        end
        QDKP2totalIndex = indexFromButton + QDKP2_ListIndex - 1  --index was off by 1 somehow
        local name = tableList[QDKP2totalIndex]
        QDKP2_PopupLog(name)
        QDKP2_ChangeSelectPlayer(name)  
        QDKP2_RefreshRoster()
    end
end
  
--Sets the player data to frames3 and 4 when target is clicked
function QDKP2_OnClick(arg1)
 
    if (CanEditOfficerNote()) then
        if( getglobal("QDKP2_Frame3"):IsVisible() ) then
            --do nothing
        else
            QDKP2frame3_reasonBox:SetText("")
            QDKP2frame3_dkpBox:SetText("")
            QDKP2_FramesOpen[3]=true
            getglobal("QDKP2_Frame3"):Show()
        end

        local buttonName = this:GetName()
        local indexFromButton = 0
        local tableList = QDKP2_RaidorGuildList()
	
        for i=1, QDKP2_numFrame2entries do
            local button = "QDKP2_frame2_entry"..i
            if(buttonName==button) then
                indexFromButton = i
            end
        end
        
    
        QDKP2totalIndex = indexFromButton + (QDKP2_ListIndex - QDKP2_numFrame2entries) 
        
        local name = tableList[QDKP2totalIndex]
        QDKP2_ChangeSelectPlayer(name)
        QDKP2_RefreshRoster()
        QDKP2_RefreshLog()
    end
end

function QDKP2_ChangeSelectPlayer(name)

	getglobal("QDKP2frame3_player"):SetText("Player: "..name)
	getglobal("QDKP2frame4_TotalBox"):SetText(QDKP2noteTotal[name])
	getglobal("QDKP2frame4_NetBox"):SetText(QDKP2noteTotal[name]-QDKP2noteSpent[name])
	getglobal("QDKP2frame4_HoursBox"):SetText(QDKP2noteHours[name])
  
  if QDKP2log_show ~= name then
    QDKP2log_show = name
    QDKP2_LogIndex = 1
    QDKP2_SelectedLogIndex = -1
    if QDKP2_Frame6:IsVisible() then
      QDKP2_Frame6:Hide()
    end
  end
  
  QDKP2totalIndexName=name
end

function QDKP2Log_OnClick(arg1)
    
	local buttonName = this:GetName()
	local indexFromButton = 0
  
  
  
	for i=1, QDKP2_numFrame5entries do
		local button = "QDKP2_frame5_entry"..i
		if(buttonName==button) then
			indexFromButton = i
		end
	end
	
	local LogIndex = indexFromButton + QDKP2_LogIndex - 1  --index was off by 1 somehow

  QDKP2_LOG_SelectLogIndex(LogIndex)
end

    
    
function QDKP2_LOG_SelectLogIndex(LogIndex)
  QDKP2_ReportBox:Hide();
  QDKP2_FramesOpen[6]=false
  QDKP2_Frame6:Hide()
  
  if QDKP2_LootToPay and QDKP2_Frame3:IsVisible() then
    QDKP2_ToggleOffAfter(3)
  end
  QDKP2_SetLootCharge(nil)
  
  if not LogIndex then
    QDKP2_SelectedLogIndex = nil
  else
    QDKP2_SelectedLogIndex = LogIndex
    
    local LogList = {}
    if QDKP2log[QDKP2log_show] then
      LogList = QDKP2log[QDKP2log_show]
    end

    local Log = LogList[LogIndex]
    local LogType = Log[QDKP2LOG_TYPE]
    local reason = Log[QDKP2LOG_ACTION]
    
    if LogType == QDKP2LOG_MODIFY or LogType == QDKP2LOG_CONFIRMED or QDKP2_IsDeletedEntry(LogType) then
    
      local gained = Log[QDKP2LOG_UNDO][1]
      local spent = Log[QDKP2LOG_UNDO][2]
      local hours = Log[QDKP2LOG_UNDO][3]
      
      if QDKP2_Frame6:IsVisible() then
      --do nothing
      else
        QDKP2_FramesOpen[6]=true
        QDKP2_Frame6:Show()
      end
      if gained then
        QDKP2frame6_GainedBox:SetText(gained)
      else
        QDKP2frame6_GainedBox:SetText("")
      end
      if spent then
        QDKP2frame6_SpentBox:SetText(spent)
      else
        QDKP2frame6_SpentBox:SetText("")
      end
      if hours then
        QDKP2frame6_HoursBox:SetText(hours)
      else
        QDKP2frame6_HoursBox:SetText("")
      end
      if reason then
        QDKP2frame6_ReasonBox:SetText(reason)
      else
        QDKP2frame6_ReasonBox:SetText("")
      end
      
    elseif LogType == QDKP2LOG_LOOT then
      
      local text = Log[QDKP2LOG_ACTION]
      
      local loot
      local name = QDKP2log_show
      
      if QDKP2log_show=="RAID" then
        local _, _, player, lootr = string.find(text, "([^%s]+) loots (.+)")
        if not QDKP2noteTotal[player] then
          return
        end
        name = player
        loot = lootr
      else
        loot = string.sub(text,7)
      end
      
      if QDKP2_Frame3:IsVisible() then
        --do nothing
      else
        QDKP2_FramesOpen[3]=true
        QDKP2_Frame3:Show()
      end
      
      QDKP2totalIndexName = name
      QDKP2_SetLootCharge(loot)
      
    elseif LogType == QDKP2LOG_LOOTLINK then
      local _,_,name = string.find(Log[QDKP2LOG_ACTION],"([^%s]+)")
      QDKP2_ChangeSelectPlayer(name)
      
    elseif LogType == QDKP2LOG_NEWSESSION then
      QDKP2_OpenInputBox("Enter the new name of the session",QDKP2log_SetNewSessionName,Log)
      QDKP2_InputBox_Data:SetText(Log[QDKP2LOG_ACTION])
    end  
  end
  
  QDKP2_RefreshRoster()
  QDKP2_RefreshLog()
  
end

------------------------------------------Frame1---------

--Allows for the up and down arrows to work on frame 1  "+" = up, "-" = down... duh

function QDKP2_frame1_DownloadData()
  QDKP2_DownloadGuild("",true)
end

function QDKP2_frame1_dkpAwardRaidSet(todo)
    if not todo then
        QDKP2_dkpAwardRaid = 0
    elseif todo=="+" then
		QDKP2_dkpAwardRaid = QDKP2_dkpAwardRaid + 1
	elseif todo=="-" then
		QDKP2_dkpAwardRaid = QDKP2_dkpAwardRaid - 1
    else
		QDKP2_dkpAwardRaid = todo
	end
    QDKP2_RaidDKPBox:SetText(QDKP2_dkpAwardRaid)
end

--increases and decreases the value of the DKP per hr
function QDKP2_frame1_dkpPerHourSet(todo)
	if not todo then
    QDKP2_dkpPerHour = 0
  elseif todo=="+" then
		QDKP2_dkpPerHour = QDKP2_dkpPerHour + 1
	elseif todo=="-" then
		QDKP2_dkpPerHour = QDKP2_dkpPerHour - 1
	else
        QDKP2_dkpPerHour = todo
  end
  QDKP2frame1_dkpBox_perhr_text:SetText(QDKP2_dkpPerHour)
end

---------------------------------------

--gives awards DKP
function QDKP2_frame1_award()
  local mess = "Write the reason of the award\n(leave blank for none)"
  QDKP2_OpenInputBox(mess,QDKP2_GUI_GiveRaidDKP)
end

function QDKP2_GUI_GiveRaidDKP(reason)
  local dkpIncrease = QDKP2_RaidDKPBox:GetText()
  QDKP2_GiveRaidDKP(dkpIncrease,reason)
end


---------------------------------------

--givs Ironman Bonus
function QDKP2_frame1_ironman(Sure)

  if QDKP2frame1_ironman:GetText()=="Start" then
    QDKP2_IronManStart()
    local mess="Do you also want to start a new session?"
    QDKP2_AskUserConf(mess, QDKP2_DownloadGuild, "",true)
  else
    local BonusDKP = tonumber(QDKP2_RaidDKPBox:GetText())
    
    if BonusDKP == 0 then
      if not Sure then
        local mess = "The Raid Bonus is set to 0.\n Do you want to discard IronMan data?"
        QDKP2_AskUserConf(mess, QDKP2_frame1_ironman, true)
        return
      end
      QDKP2_Msg("IronMan data discarded")
      QDKP2_IronManWipe()
    else
      if not Sure then
        local mess = "Close the IronMan bonus and\n award to the winners "..QDKP2_RaidDKPBox:GetText().." DKP?"
        QDKP2_AskUserConf(mess, QDKP2_frame1_ironman, true)
        return
      end
      
      local BonusList = QDKP2_InronManFinish()
      for i=1, table.getn(BonusList) do
        local name = BonusList[i]
        QDKP2_AddTotals(name,BonusDKP, nil, nil, "Iron Man bonus", EndMark, true, false)
      end
      
      QDKP2log_Entry("RAID","Iron Man bonus", QDKP2LOG_MODIFY, BonusDKP, {BonusDKP,nil,nil},EndMark)
      
      if table.getn(BonusList)==0 then
        QDKP2_Msg(QDKP2_COLOR_GREY.."No one awarded the Iron Man Bonus.")
      else
        QDKP2_Msg(QDKP2_COLOR_BLUE..table.getn(BonusList).." players awarded the Iron Man bonus. Upload the changes to save them. Reset to discard.")
      end
      QDKP2frame1_ironman:SetText("Start")
      QDKP2_RefreshLog()
      if QDKP2_SENDTRIG_IRONMAN then
        QDKP2_UploadAll()
      end
    end
    if QDKP2_TimerBase then
      local mess = "The Raid Timer is still active.\n Do you want to turn it off?"
      QDKP2_AskUserConf(mess,QDKP2_TimerOff)
    end
  end
end
---------------------------------------

--toggles the off/on button for the timer
function QDKP2_frame1_offOnToggle(todo)
	local frame = getglobal("QDKP2_frame1_onOff")
    if(frame:GetText()=="OFF")then
		QDKP2_TimerOff()
	else
        QDKP2_TimerOn()
	end
end

----------------------------------------FRAME 2 ------------

--Sorts by name
function QDKP2_frame2_sort_by_name()

  QDKP2_Order="Alpha"

	QDKP2_RefreshRoster()
end

--sorts by class and net
function QDKP2_frame2_sort_by_class()

  QDKP2_Order="Class"

	QDKP2_RefreshRoster()
end

--sorts by rank and name
function QDKP2_frame2_sort_by_rank()

  QDKP2_Order="Rank"

	QDKP2_RefreshRoster()
  
end

--sort by net
function QDKP2_frame2_sort_by_net()
  
  QDKP2_Order = "Net"
  
  QDKP2_RefreshRoster()
  
end

-- sort by priority
function QDKP2_frame2_sort_by_priority()
  
  QDKP2_Order = "Priority"
  
  QDKP2_RefreshRoster()
  
end

-- sort by Hours
function QDKP2_frame2_sort_by_hours()
  
  QDKP2_Order = "Hours"
  
  QDKP2_RefreshRoster()
  
end

----------------------------------------FRAME 3 ------------



function QDKP2_PopupTB(name)
  QDKP2_ChangeSelectPlayer(name)
  QDKP2_Toggle(3,true)
end
  
--Modifies info in pane 2 from pane 3
function QDKP2_frame3_awardspend(inctype,Sure)
	local list = QDKP2_RaidorGuildList()
	local name = QDKP2totalIndexName
	
	local change = tonumber(getglobal("QDKP2frame3_dkpBox"):GetText())
  
  if not change or change == 0 then return; end
  
  local loot = QDKP2_LootToPay
  local reason = QDKP2frame3_reasonBox:GetText()
  if reason == "" then reason = nil; end
	if(inctype=="+") then
        if loot and not Sure then
            local mess = "Really Give DKP for the\n loot of an object?"
            QDKP2_AskUserConf(mess, QDKP2_frame3_awardspend, "+", true)
            return
        end
        if loot then
            QDKP2_PayLoot(name, -change, loot)
        else
            QDKP2_AddTotals(name,change ,nil ,nil, reason, nil, true, true)
        end
    
	elseif(inctype=="-")then
        if loot then 
            QDKP2_PayLoot(name, change, loot)
        else
            QDKP2_AddTotals(name,nil ,change ,nil, reason, nil, true, true)
        end
	end
  

	QDKP2frame4_TotalBox:SetText(QDKP2noteTotal[name])
	QDKP2frame4_NetBox:SetText(QDKP2noteTotal[name]-QDKP2noteSpent[name])
	
	QDKP2_RefreshRoster()
    QDKP2_RefreshLog()
  
    if loot then
        QDKP2_ToggleOffAfter(3)
        QDKP2_SetLootCharge(nil)
    end
end

function QDKP2_frame3_ResetChanges(Sure)
  local name = QDKP2totalIndexName
  if not Sure then
    local mess = "Do you want to reset "..name.."'s\n counters, download the values in officer\n notes and start a new session for him?"
    QDKP2_AskUserConf(mess,QDKP2_frame3_ResetChanges,true)
  else
    QDKP2noteTotal[name] = nil
    QDKP2_StopCheck()
    QDKP2_DownloadGuild(nil,false)
  end
end
---------------------------------------

function QDKP2_SetDKPbox(Value)
  QDKP2frame3_dkpBox:SetText(Value)
end

function QDKP2_SetLootCharge(item)
  if QDKP2_LootToPay or item then
    if not item then
      QDKP2frame3_reasonBox:SetText("")
    else
      QDKP2frame3_reasonBox:SetText(item)
    end
    QDKP2_LootToPay = item
    QDKP2_CancelFirstOnChange=true
  end
end


--QDKP2_OpenToolboxForCharge
--Opens the toolbox to charge a player for a loot. all parameters are optionals
--usage f([name],[amount],[item]) 
--name=valid name of a player in guild
--amount=the amount of DKP to charge to the player
--item=The reason of the charge (e.g. item link)

function QDKP2_OpenToolboxForCharge(name,amount,item) 
  if QDKP2_Frame3:IsVisible() then
    --do nothing
  else
    QDKP2_FramesOpen[3]=true
    QDKP2_Frame3:Show()
  end
  if name then
    QDKP2totalIndexName = name
    QDKP2frame3_player:SetText("Player: "..name)
    QDKP2frame4_TotalBox:SetText(QDKP2noteTotal[name])
    QDKP2frame4_NetBox:SetText(QDKP2noteTotal[name]-QDKP2noteSpent[name])
    QDKP2frame4_HoursBox:SetText(QDKP2noteHours[name])
  end
  if item then
    QDKP2_SetLootCharge(item)
  end
  if amount then
    QDKP2_Chron_schedule(0.01,QDKP2_SetDKPbox,amount)
  else
    QDKP2_Chron_schedule(0.01,QDKP2_SetDKPbox,"")
  end
end
    

---------------------------------------

--notifies the selected target
function QDKP2_frame3_notifyTarget(SendReport)   
	local list = QDKP2_RaidorGuildList()
	local name = QDKP2totalIndexName
	QDKP2_Notify(name)
  if SendReport == nil then
    local mess = "Do you want to report also\n the log of the last session?"
    QDKP2_AskUserConf(mess,QDKP2_MakeAndSendReport, name ,"Session", 1,"WHISPER",name)
  end
end

----------------------------------------FRAME 4 ------------

--sets data from frame 4
function QDKP2_frame4_setinfo()
	local net = getglobal("QDKP2frame4_NetBox"):GetText()
	local total = getglobal("QDKP2frame4_TotalBox"):GetText()
	local hours = getglobal("QDKP2frame4_HoursBox"):GetText()
	local tableList = QDKP2_RaidorGuildList()
  
	local name = QDKP2totalIndexName
  
  if net=="" then net = nil; else net = tonumber(net); end
  if total=="" then total = nil; else total = tonumber(total); end
  if hours=="" then hours = nil; else hours = tonumber(hours); end
  
  local DTotal = total - QDKP2noteTotal[name]
  local DSpent = total - net - QDKP2noteSpent[name]
  local DHours = hours - QDKP2noteHours[name]
  
  QDKP2_AddTotals(name, DTotal, DSpent, DHours, "Manual edit", nil, true, true)
  
	QDKP2_RefreshRoster()
  QDKP2_RefreshLog()
  
end




---------------------------------------

--gives selected player 1 hour
function QDKP2_frame4_give1hour()
	local list = QDKP2_RaidorGuildList()
	local name = QDKP2totalIndexName
	QDKP2noteHours[name] = QDKP2noteHours[name] +1
	QDKP2hours[name] = QDKP2hours[name] +1
  QDKP2log_Entry(name,nil,QDKP2LOG_MODIFY,nil,{nil,nil,1})
  
	QDKP2frame4_HoursBox:SetText(QDKP2noteHours[name])
  QDKP2_StopCheck()
  
	QDKP2_RefreshRoster()
  QDKP2_RefreshLog()
end

---------------------------------------Frame Utility---------------

--Figures out which list is needed and is returned
function QDKP2_RaidorGuildList()
	local tableList
	if(QDKP2_DropDownMenu_ID == 2) then
        tableList = QDKP2name
    elseif (QDKP2_DropDownMenu_ID == 3) then
    --  tableList = QDKP2bidders
    else
        tableList = QDKP2raid
    end
    return tableList
end

--------------------------------------Frame 5---------------------------------

function QDKP2_PopupLog(name)

  local usedName
  
  if name then usedName = name
  else usedName = QDKP2totalIndexName
  end
  
  QDKP2_SelectedLogIndex = 0
  if QDKP2_Frame6:IsVisible() then QDKP2_Frame6:Hide(); end

  if name == "RAID" then
    QDKP2totalIndexName = ""
    if QDKP2_Frame3:IsVisible() then
      QDKP2_ToggleOffAfter(3)
    end
  end
  
  if usedName == QDKP2log_show then
    QDKP2_ToggleOffAfter(5, false)
  end
  
  if QDKP2log_show ~= usedName then
    QDKP2log_show = usedName
    QDKP2_LogIndex = 1
    QDKP2_SelectedLogIndex = -1
    QDKP2_Frame5:Show()
    if QDKP2_Frame6:IsVisible() then QDKP2_Frame6:Hide(); end
  end
  
  QDKP2_RefreshLog()
  QDKP2_RefreshRoster()
end

function QDKP2_ChangeReportType(reportType)
  local checkName = this:GetName()
  for i=1,7 do
    local toCheck = "QDKP2frame2_ReportType"..i
    if toCheck == checkName then
      getglobal(toCheck):SetChecked(true)
    else
      getglobal(toCheck):SetChecked(false)
    end
  end
  QDKP2_ReportType = reportType
end

function QDKP2_ChangeReportChannel(reportChannel)
  local checkName = this:GetName()
  for i=1,6 do
    local toCheck = "QDKP2frame2_ReportChannel"..i
    if toCheck == checkName then
      getglobal(toCheck):SetChecked(true)
    else
      getglobal(toCheck):SetChecked(false)
    end
  end
  QDKP2_ReportChannel = reportChannel
end

function QDKP2_ReportGo()
  if QDKP2_ReportType and QDKP2_ReportChannel then
    QDKP2_ReportBox:Hide()
    QDKP2_MakeAndSendReport(QDKP2_ReportName,QDKP2_ReportType,QDKP2_ReportIndex,QDKP2_ReportChannel)
  end
end
----------------------------------------------- Frame 6 -----------------------------------
-- This will delete (undo) the selected log entry
function QDKP2_frame6_UnDo()
  local Type = QDKP2log[QDKP2log_show][QDKP2_SelectedLogIndex][QDKP2LOG_TYPE]
  QDKP2_LOG_UnDoEntry(QDKP2log_show,QDKP2_SelectedLogIndex)
  if QDKP2log_show == "RAID" then
    QDKP2timestamp=QDKP2log[QDKP2log_show][QDKP2_SelectedLogIndex][QDKP2LOG_TIME]
    QDKP2changecont = QDKP2log[QDKP2log_show][QDKP2_SelectedLogIndex][QDKP2LOG_ACTION]
    if QDKP2_IsDeletedEntry(Type) then
      QDKP2onoff = "on"
    else
      QDKP2onoff = "off"
    end
    table.foreach(QDKP2log, QDKP2_RAID_UnDoLogEntry)
  end
  QDKP2_RefreshRoster()
  QDKP2_RefreshLog()
end

function QDKP2_RAID_UnDoLogEntry(name,LogList)
  if name == "RAID" then
    return
  end
  for i = 1, table.getn(LogList) do
    if LogList[i][QDKP2LOG_TIME] == QDKP2timestamp and LogList[i][QDKP2LOG_ACTION] == QDKP2changecont then
      QDKP2_LOG_UnDoEntry(name,i,QDKP2onoff)
      break
    end
  end
end

function QDKP2_frame6_setEntry()
  local gained = (QDKP2frame6_GainedBox:GetText())
  local spent = (QDKP2frame6_SpentBox:GetText())
  local hours = (QDKP2frame6_HoursBox:GetText())
  local reason = (QDKP2frame6_ReasonBox:GetText())
  local oldreason = QDKP2log[QDKP2log_show][QDKP2_SelectedLogIndex][QDKP2LOG_ACTION]
  local oldtime = QDKP2log[QDKP2log_show][QDKP2_SelectedLogIndex][QDKP2LOG_TIME]
  QDKP2_SetLogEntry(QDKP2log_show,QDKP2_SelectedLogIndex,gained,spent,hours,reason)
  if QDKP2log_show == "RAID" then
    QDKP2changecont = oldreason
    QDKP2timestamp = oldtime
    QDKP2setGained = gained
    QDKP2setSpent = spent
    QDKP2setHours = hours
    QDKP2setReason = reason
    table.foreach(QDKP2log, QDKP2_RAID_SetLogEntry)
  end
  QDKP2_RefreshLog()
  QDKP2_RefreshRoster()
end

function QDKP2_RAID_SetLogEntry(name,LogList)
  if name == "RAID" then
    return
  end
  for i = 1, table.getn(LogList) do
    if LogList[i][QDKP2LOG_TIME] == QDKP2timestamp and LogList[i][QDKP2LOG_ACTION] == QDKP2changecont then
      QDKP2_SetLogEntry(name,i,QDKP2setGained,QDKP2setSpent,QDKP2setHours,QDKP2setReason)
      break
    end
  end
end


----------------------------------------------- VAR ----------------------------

function QDKP2_OpenInputBox(text,func,arg2,arg3,arg4,arg5)

  QDKP2_InputBox_text:SetText(text)
  QDKP2_InputBox_Data:SetText("")
  QDKP2_InputBox_Data:SetFocus()
  QDKP2_InputBox:Show()
  QDKP2_InputBox_func=func
  QDKP2_InputBox_arg2=arg2
  QDKP2_InputBox_arg3=arg3
  QDKP2_InputBox_arg4=arg4
  QDKP2_InputBox_arg5=arg5
end

function QDKP2_InputBox_OnEnter()
  QDKP2_InputBox:Hide()
  local data=QDKP2_InputBox_Data:GetText()
  if data == "" then data = nil; end
  QDKP2_InputBox_func(data,QDKP2_InputBox_arg2,QDKP2_InputBox_arg3,QDKP2_InputBox_arg4,QDKP2_InputBox_arg5)
end



function QDKP2_AskUserConf(text,func,arg1,arg2,arg3,arg4,arg5)
  
  QDKP2_WarningBox_text:SetText(text)  
  QDKP2_WarningBox:Show()
  QDKP2_WarningBox_func=func
  QDKP2_WarningBox_arg1=arg1
  QDKP2_WarningBox_arg2=arg2
  QDKP2_WarningBox_arg3=arg3
  QDKP2_WarningBox_arg4=arg4  
  QDKP2_WarningBox_arg5=arg5 
end

function QDKP2_AskUserConf_OnEnter(PressedYes)
  QDKP2_WarningBox:Hide()
  if PressedYes then
    QDKP2_WarningBox_func(QDKP2_WarningBox_arg1, QDKP2_WarningBox_arg2, QDKP2_WarningBox_arg3, QDKP2_WarningBox_arg4, QDKP2_WarningBox_arg5)
  end
end
  