-- Copyright 2006 Riccardo Belloli
-- This file is a part of QDKP_V2 (see QDKP_V2.lua)
--                    ## LOGGING SYSTEM ##

 
--------------------------------------LOG GLOBALS--------------------------

QDKP2LOG_CONFIRMED = 1
QDKP2LOG_EVENT = 2
QDKP2LOG_CRITICAL = 3
QDKP2LOG_MODIFY = 4
QDKP2LOG_NEWSESSION = 5
QDKP2LOG_LOST = 6
QDKP2LOG_JOINED = 7
QDKP2LOG_LEAVED = 8
QDKP2LOG_OFFLINE = 9
QDKP2LOG_LOOT = 10
QDKP2LOG_LOOTLINK = 11
QDKP2LOG_ABORTED = 12

QDKP2LOG_NET = 1
QDKP2LOG_CHANGE = 2
QDKP2LOG_ACTION = 3
QDKP2LOG_TYPE = 4
QDKP2LOG_TIME = 5
QDKP2LOG_UNDO = 6
QDKP2LOG_RAIDFLAG = 10
 
 
 
QDKP2log = {}

------------------- Logging Main Functions -------------------

--[[Add to the Log an entry
  Usage QDKP2_Entry (name, action, type, [mod], [undo], [timestamp])
    name: string, the name of the player to loc. Can be "RAID" for raid log
    action: string, the action that has to ble logged
    type: an identifier of the log entry. can be QDKP2LOG_EVENT, QDKP2LOG_CRITICAL,... (look at the beginning of the file)
    mod: optional integer, specify a gain/loss in the net DKP.
    undo: a table with this structure: {[1]=x, [2]=y, [3]=z}. used to undo that command (on click)}
          x= total increase, y= spent increase and z=hours increase
]]--

function QDKP2log_Entry(name2,action2,type2,mod2, undo2, timestamp2)

  if not QDKP2log[name2] then
    QDKP2log[name2] = {}
  end
  
  local net
  if QDKP2noteTotal[name2] then
    net = QDKP2noteTotal[name2]-QDKP2noteSpent[name2]
  end
  
  local seconds = time()
  if timestamp2 then
    seconds = timestamp2
  end
  
  local tempEntry = {net, mod2, action2, type2, seconds, undo2}
  if name2 == "RAID" then tempEntry[QDKP2LOG_RAIDFLAG]=1; end
  local tempLog={}
  
  local indexBegin = 1 --i use this to avoid 2 consecutive "--New session started--" Entries.
  if table.getn(QDKP2log[name2]) > 0 then
    if QDKP2log[name2][1][QDKP2LOG_TYPE] == QDKP2LOG_NEWSESSION  and type2 == QDKP2LOG_NEWSESSION then indexBegin = 2; end
  end

  --add the entry at the top of the log
  table.insert(tempLog,tempEntry)
  local Size = table.getn(QDKP2log[name2])
  if Size > QDKP2_LOG_MAX_SIZE then Size = QDKP2_LOG_MAX_SIZE;end
  for i=indexBegin,Size do
    table.insert(tempLog,QDKP2log[name2][i])
  end
  
  QDKP2log[name2] = tempLog  
end

-- Called after a confirmed upload or reset, change the log_type of all the last QDKP2LOG_MODIFY to a new type.
-- if called wit true will change them in QDKP2LOG_CONFIRMED, with false with QDKP2LOG_LOST

function QDKP2log_ConfirmEntries(name,successup)
  local UploadProblems = false
  local HasBeenConfirmed = false
  local LogList = QDKP2log[name]
  local entries = 0
  if LogList then
    entries = table.getn(LogList)
  end
  
  for i=1, entries do  
    local Type = LogList[i][QDKP2LOG_TYPE]
    if Type == QDKP2LOG_CRITICAL and not HasBeenConfirmed then
      UploadProblems = true               --if i had problems on the upload remind that
    elseif Type == QDKP2LOG_MODIFY and successup then
       LogList[i][QDKP2LOG_TYPE] = QDKP2LOG_CONFIRMED   --change all the logtype for the entry after the last confirmed align
    elseif Type == QDKP2LOG_MODIFY and not successup then
       LogList[i][QDKP2LOG_TYPE] = QDKP2LOG_ABORTED
    end
    if Type == QDKP2LOG_NEWSESSION or Type==QDKP2LOG_CONFIRMED then
      HasBeenConfirmed = true
    end
  end

  if UploadProblems then
    QDKP2log_Entry(name,"CHECK: Now the values are aligned",QDKP2LOG_NEWSESSION) --if i had problems specify that now i am ok
    QDKP2_Msg(QDKP2_COLOR_GREEN..name.." is now correctly aligned with officernotes.")
    QDKP2_RefreshLog()
  end
end


-- purging function based on days before now. 
-- it's based on the time() function, wich gives the second after the epoch

function QDKP2_LOG_PurgeDays(days, Sure)
  if not Sure then
    mess = "Do you want to cancell all log entries\n older than "..days.." days?" 
    QDKP2_AskUserConf(mess,QDKP2_LOG_PurgeDays, days, true)
    return
  end
  local LogList = ListFromDict(QDKP2log)
  local tempLog = {}
  local MyTime = time()
  for i=1, table.getn(LogList) do
    local Name=LogList[i]
    if QDKP2_IsInGuild(Name) or Name=="RAID" then       -- don't process ppl no more in guild (delete them)
      local Log = QDKP2log[Name]
      local LogSize = table.getn(Log)
      local tempNameLog = {}
      for j=1, LogSize do
        local index = LogSize - j + 1
        local LogTime=Log[j][QDKP2LOG_TIME]
        if (MyTime-LogTime)/86400 < days then --keep only the entries with less than (days) (in a day we have 86400 seconds).
          table.insert(tempNameLog, Log[j])
        else
          break
        end
      end
      tempLog[Name] = tempNameLog
    end
  end

  QDKP2log = tempLog
  QDKP2_RefreshLog()
end

function QDKP2_LOG_PurgeDeleted(Sure)
  if not Sure then
    mess = "Do you want to cancell\n all deleted log entries?" 
    QDKP2_AskUserConf(mess, QDKP2_LOG_PurgeDeleted, true)
    return
  end
  local LogList = ListFromDict(QDKP2log)
  local logLength = table.getn(LogList)
  local tempLog = {}
  for i=1, logLength do
    local Name = LogList[i]
    if QDKP2_IsInGuild(Name) or Name=="RAID" then       -- don't process ppl no more in guild (delete them)
      local Log = QDKP2log[Name]
      local LogSize = table.getn(Log) 
      local tempNameLog = {}
      for j=1, LogSize do
        local logType = Log[j][QDKP2LOG_TYPE]
        if logType ~= QDKP2LOG_ABORTED and logType ~= QDKP2LOG_LOST then
          table.insert(tempNameLog, Log[j])
        end
      end
      tempLog[Name] = tempNameLog
    end
  end
  QDKP2log = tempLog
  QDKP2_RefreshLog()
  end
  
function QDKP2_LOG_PurgeSessions(number,Sure)
  if not Sure then
    mess = "Do you want to cancell all log entries\n except for last "..number.." sessions?" 
    QDKP2_AskUserConf(mess,QDKP2_LOG_PurgeSessions, number, true)
    return
  end
  local LogList = ListFromDict(QDKP2log)
  local tempLog = {}
  for i=1, table.getn(LogList) do
    local Name = LogList[i]
    if QDKP2_IsInGuild(Name) or Name=="RAID" then       -- don't process ppl no more in guild (delete them)
      local Log = QDKP2log[Name]
      local LogSize = table.getn(Log)
      local logSession = 0
      local tempNameLog = {}
      for j=1, LogSize do
        table.insert(tempNameLog, Log[j])
        local logType = Log[j][QDKP2LOG_TYPE]
        if logType == QDKP2LOG_NEWSESSION then
          logSession = logSession + 1
          if logSession >= number then
            break
          end
        end
      end
      tempLog[Name] = tempNameLog
    end
  end
  QDKP2log = tempLog
  QDKP2_RefreshLog()
end  

  
function QDKP2_LOG_PurgeWipe(Sure)
  if not Sure then
    mess = "Do you want to cancel\n all the log data?" 
    QDKP2_AskUserConf(mess,QDKP2_LOG_PurgeWipe, true)
    return
  end  
  QDKP2log = {}
  QDKP2_RefreshLog()
end



function QDKP2_LOG_UnDoEntry(name,index,onofftog)
  local LogList = QDKP2log[name]
  local Log=LogList[index]
  local LogType=Log[QDKP2LOG_TYPE]
  local UnDo = Log[QDKP2LOG_UNDO]
  local DTotal = UnDo[1]
  local DSpent = UnDo[2]
  local DHours = UnDo[3]
  local DeltaDKP = 0
  local onoff=""
  if onofftog then
    onoff = onofftog
  end
    
  local addsub = 0
  if onoff == "on" then
    if QDKP2_IsDeletedEntry(LogType) then
      addsub = 1
    end
  elseif onoff == "off" then
    if not QDKP2_IsDeletedEntry(LogType) then
      addsub = -1
    end
  elseif QDKP2_IsDeletedEntry(LogType) then
    addsub = 1
  elseif not QDKP2_IsDeletedEntry(LogType) then
    addsub = -1
  end
  
  if DTotal then 
    DTotal = DTotal *addsub
    DeltaDKP = DTotal
  end
  
  if DSpent then 
    DSpent = DSpent *addsub
    DeltaDKP = DeltaDKP - DSpent
  end
  
  if DHours then 
    DHours = DHours *addsub
  end
  
  if name ~= "RAID" then
    QDKP2_AddTotals(name, DTotal, DSpent, DHours)
  end
    
  local newType
  
  if addsub==1 then
    newType = QDKP2LOG_MODIFY
  else
    newType = QDKP2LOG_ABORTED
  end
  
  Log[QDKP2LOG_TYPE] = newType  
  
  for i=index, 1, -1 do
    local LogEdit = LogList[i]
    if LogEdit[QDKP2LOG_NET] then
      LogEdit[QDKP2LOG_NET] = LogEdit[QDKP2LOG_NET] + DeltaDKP
    end
  end
end

function QDKP2_DeleteLogEntry(name,index)
  local IsModifiedBefore = QDKP2_IsModified(name)
  local tempLog = {}
  if index>1 then
    for i=1, index-1 do
      table.insert(tempLog,QDKP2log[name][i])
    end
  end
  if index<table.getn(QDKP2log[name]) then
    for i=index+1,table.getn(QDKP2log[name]) do
      table.insert(tempLog,QDKP2log[name][i])
    end
  end
  if QDKP2_Frame6:IsVisible() then
    QDKP2_Frame6:Hide()
  end
  
  QDKP2_SelectedLogIndex = 0
  
  local Log_Backup = QDKP2_CopyTable(QDKP2log)
  QDKP2log[name] = tempLog
  
end

function QDKP2_SetLogEntry(name,index,NewGained,NewSpent,NewHours,NewReason)
  local Log = QDKP2log[name][index]
  local Undo = Log[QDKP2LOG_UNDO]
  local LogType = Log[QDKP2LOG_TYPE]
  local oldGained = Undo[1]
  local oldSpent = Undo[2]
  local oldHours = Undo[3]
  local newGained = NewGained
  local newSpent = NewSpent
  local newHours = NewHours
  local newReason = NewReason
  local Dnet = 0
  
  if not oldGained then
    oldGained = "0"
  end
  if not oldSpent then
    oldSpent = "0"
  end
  if not oldHours then
    oldHours = "0"
  end
  if NewGained == "" then
    newGained = "0"
  end
  if NewSpent == "" then
    newSpent = "0"
  end
  if NewHours == "" then
    newHours = "0"
  end
  
  newGained = tonumber(newGained)
  newSpent = tonumber(newSpent)
  newHours = tonumber(newHours)
  
  oldGained = tonumber(oldGained)
  oldSpent = tonumber(oldSpent)
  oldHours = tonumber(oldHours)
  
  Dnet = (newGained-oldGained) - (newSpent-oldSpent)
  
  if not QDKP2_IsDeletedEntry(LogType) and name ~= "RAID" then
    QDKP2noteTotal[name] = QDKP2noteTotal[name] + newGained - oldGained
    QDKP2gained[name] = QDKP2gained[name] + newGained - oldGained
    QDKP2noteSpent[name] = QDKP2noteSpent[name] + newSpent - oldSpent
    QDKP2spent[name] = QDKP2spent[name] + newSpent - oldSpent
    QDKP2noteHours[name] = QDKP2noteHours[name] + newHours - oldHours
    QDKP2hours[name] = QDKP2hours[name] + newHours - oldHours  
    QDKP2_StopCheck()
  end
  
  Dgained = newGained - oldGained
  Dspent = newSpent - oldSpent
  Dhours = newHours - oldHours
  
  if Dgained ~= 0 or Dspent ~= 0 or abs(Dhours)>0.09 then
    if LogType == QDKP2QDKP2LOG_CONFIRMED then
      QDKP2log[name][index][QDKP2LOG_TYPE] = QDKP2LOG_MODIFY
    end
  end
  
  local newChange = newGained-newSpent
  
  if newGained == 0 then 
    newGained = nil
  end
  if newSpent == 0 then 
    newSpent = nil
  end
  if newHours == 0 then 
    newHours = nil
  end
  if newReason == "" then
    newReason = nil
  end
  
  QDKP2log[name][index][QDKP2LOG_UNDO]={newGained,newSpent,newHours}
  QDKP2log[name][index][QDKP2LOG_ACTION] = newReason
  
  if QDKP2log[name][index][QDKP2LOG_CHANGE] then
    QDKP2log[name][index][QDKP2LOG_CHANGE] = newChange
  end
  
  for i=index, 1, -1 do
    local LogNet = QDKP2log[name][i][QDKP2LOG_NET]
    if LogNet then
      QDKP2log[name][i][QDKP2LOG_NET] = LogNet + Dnet
    end
  end
end

;---------------------------------- UTILITY ---------------------------------

function QDKP2log_SetNewSessionName(NewSessionName,Log)
  local timeStamp = Log[QDKP2LOG_TIME]
  local LogList = ListFromDict(QDKP2log)
  for i=1,table.getn(LogList) do
    for j=1,table.getn(QDKP2log[LogList[i]]) do
      local LogToEdit = QDKP2log[LogList[i]][j]
      if LogToEdit[QDKP2LOG_TIME]==timeStamp and LogToEdit[QDKP2LOG_TYPE]==QDKP2LOG_NEWSESSION then
        LogToEdit[QDKP2LOG_ACTION] = NewSessionName
      end
    end
  end
  QDKP2_RefreshLog()
end

--returns the date and time for the log voice passed
function QDKP2log_GetModEntryDateTime(LogEntry)
  local datestring = ""
  local entryTime = LogEntry[QDKP2LOG_TIME]
  local nowTime = time()
  if date("%x",nowTime) == date("%x",entryTime) or nowTime-entryTime < 3600 * QDKP2_DATE_TIME_TO_HOURS then
    datestring = date("%H:%M:%S",entryTime)
  elseif nowTime-entryTime < 86400 * QDKP2_DATE_TIME_TO_DAYS + tonumber(date("%H",nowTime))*3600 + tonumber(date("%M",nowTime))*60 then
    datestring = date("%a %H:%M",entryTime)
  else
    datestring = date("%d/%m %H:%M",entryTime)
  end
  return datestring
end

-- returns the "action", the log description. If not a modify entry is simply the
-- ACTION field, but with the modify entries it nuild it from the gained/spent
-- data.
function QDKP2log_GetModEntryText(Log)
  local Type = Log[QDKP2LOG_TYPE]
  local reason = Log[QDKP2LOG_ACTION]
  local output = ""
  
  if  (Type == QDKP2LOG_MODIFY or QDKP2_IsDeletedEntry(Type) or Type == QDKP2LOG_CONFIRMED) then
    if not Log[QDKP2LOG_UNDO] then
      return ""
    end
    
    local gained = Log[QDKP2LOG_UNDO][1]
    local spent = Log[QDKP2LOG_UNDO][2]
    local hours = Log[QDKP2LOG_UNDO][3]
    
    if Log[QDKP2LOG_RAIDFLAG] then
      output = "Raid "
    end
    
    if gained then
      output=output.."Gains "..gained.." DKP"
    end
    if spent then
      if gained then
        output=output..", "
      end
      output = output.."Spends "..spent.." DKP"
    end
    if hours then
      if gained or spent then
        output = output..", "
      end
      output = output.."Earn "..hours.." Hours"
    end
    if reason then
      output = output.." for "..reason
    end
  elseif Type==QDKP2LOG_NEWSESSION then
    if reason then
      output = "Session Started: "..reason
    else
      output = "Unnamed Session Started"
    end
  else
    output = reason
  end
  
  return output
end

-- return true if the log entry is a Deleted entry
function QDKP2_IsDeletedEntry(Type)
  if Type == QDKP2LOG_LOST or Type == QDKP2LOG_ABORTED then
    return true
  end
end


-------------------------------- REPORTS -----------------------------------

--this will create the report and send it on the given channel (GetReport+SendList)
function QDKP2_MakeAndSendReport(name,reportType,index,channel,channelSub) 
  local reportList = QDKP2_GetReport(name,reportType,index)
  QDKP2_SendList(reportList,channel,channelSub)
end

function QDKP2_SendListGetChannelSub(channelSub,List,channel)
  QDKP2_SendList(List,channel,channelSub)
end

function QDKP2_SendList(List,channel,channelSub)
  if channel == "CHANNEL" and not channelSub then
    QDKP2_OpenInputBox("Please enter the number of the channel\n to send the report",QDKP2_SendListGetChannelSub, List, channel)
    return
  end  
  if channel == "WHISPER" and not channelSub then
    QDKP2_OpenInputBox("Please enter the name of the player\n to send the report",QDKP2_SendListGetChannelSub, List, channel)
    return
  end
  for i=1, table.getn(List) do
    SendChatMessage(List[i],channel,nil,channelSub)
  end
end

function QDKP2_GetReport(name,reportType,index)
  if not index then index = 1; end
  LogList=QDKP2log[name]
  if not LogList then return; end
  LogLength = table.getn(LogList)
  if LogLength == 0 then return; end
  local reportList = {}
  
  if reportType == "All" then
    reportList = QDKP2_Invert(LogList)
    
  elseif reportType == "All after index" then
    for i=index, 1, -1 do
      table.insert(reportList, LogList[i])
    end
    
  elseif reportType == "All untill index" then
    for i=LogLength, index, -1 do
      table.insert(reportList, LogList[i])
    end
    
  elseif reportType == "Session" then
    local c
    for i=index, LogLength do
      sessionStart=i
      if LogList[i][QDKP2LOG_TYPE] == QDKP2LOG_NEWSESSION then
        break
      end
    end
    table.insert(reportList, LogList[sessionStart])
    for i=sessionStart-1, 1, -1 do
      if LogList[i][QDKP2LOG_TYPE] == QDKP2LOG_NEWSESSION then
        break
      end
      table.insert(reportList, LogList[i])
    end
    
  elseif reportType == "Session after index" then
    table.insert(reportList, LogList[index])
    for i=index-1, 1, -1 do
      if LogList[i][QDKP2LOG_TYPE] == QDKP2LOG_NEWSESSION then
        break
      end
      table.insert(reportList, LogList[i])
    end
    
  elseif reportType == "Session untill index" then
    for i=index, LogLength do
      table.insert(reportList, LogList[i])
      if LogList[i][QDKP2LOG_TYPE] == QDKP2LOG_NEWSESSION then
        break
      end
    end
    reportList=QDKP2_Invert(reportList)
    
  elseif reportType == "index" then
    table.insert(reportList, LogList[index])
  end
  
  local header = QDKP2_Reports_Intest..string.gsub(QDKP2_Reports_Header, '<name>', name)
  header = string.gsub(header, '<type>', reportType)
  
  local tail = QDKP2_Reports_Intest..QDKP2_Reports_Tail
  
  return QDKP2_GetReportLines(name, reportList, header, tail)  
end

function QDKP2_GetReportLines(name, LogList, header, tail) --returns a list with the lines of the report

  local output = {}
  if header then
    output = {}
    output = {header,
              "   Time      Net       Action",
              "--------------------------------",
              }
  end
  
  local NoUploadedYet
  for i=1, table.getn(LogList)  do
    local Log = LogList[i]
    local Type = Log[QDKP2LOG_TYPE]
    if not QDKP2_IsDeletedEntry(Type) then
      local net = Log[QDKP2LOG_NET]
      local action = QDKP2log_GetModEntryText(Log)
      local datetime = QDKP2log_GetModEntryDateTime(Log)
      local str
      if net then
        str=datetime.." <"..net.."> "..action
      else
        str=datetime.." - "..action
      end
      if Type==QDKP2LOG_MODIFY then 
        str=str.." (*)"
        NoUploadedYet=true
      end
      table.insert(output, str)
    end
  end
  
  if tail then
    table.insert(output, "--------------------------------")
    if NoUploadedYet then
      table.insert(output, "(*): This voice has not been syncronized with officernotes yet.")
    end
    table.insert(output, tail)
  end
  return output
end
    
